import tailwindcss from "@tailwindcss/vite";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import react from "@vitejs/plugin-react";
import { nitro } from "nitro/vite";
import { resolve } from "node:path";
import { defineConfig } from "vite";

export default defineConfig({
  resolve: {
    alias: {
      "@/lib": resolve(process.cwd(), "src/libs"),
      "@": resolve(process.cwd(), "src"),
    },
  },
  plugins: [
    tanstackStart({
      srcDirectory: "./src",
      router: { entry: "routes" },
      server: { entry: "server" },
    }),
    nitro(),
    react(),
    tailwindcss(),
  ],
});
