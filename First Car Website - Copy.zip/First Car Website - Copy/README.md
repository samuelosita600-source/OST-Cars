## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

Before starting the app, copy `.env.example` to `.env` and fill in the values from the Supabase project settings. The publishable key is used by the browser; keep the service role key server-only.

To enable the admin dashboard for an existing account, run this in the Supabase SQL editor:

```sql
insert into public.user_roles (user_id, role)
select id, 'admin'::public.app_role
from auth.users
where lower(email) = lower('samuelosita600@gmail.com')
and not exists (
	select 1
	from public.user_roles
	where user_id = auth.users.id
	and role = 'admin'::public.app_role
);
```

## Stack

- TanStack Start
- TypeScript
- React 19
- Tailwind CSS 4
- TanStack Router
- Supabase Auth and Postgres
- Vite and Nitro

