# Google OAuth setup for Supabase

1. Open your Supabase project.
2. Go to Authentication > Providers.
3. Turn on Google.
4. Add your Google OAuth client ID and secret.
5. In the Google Cloud Console, create an OAuth client for a web app.
6. Add the redirect URI:
   - http://localhost:3000/account
   - https://your-production-domain.com/account
7. Save the provider.
8. In the app, use the Google sign-in button on the login page.

## Local test URL

Use this for local development:

http://localhost:3000/account

## Notes

- The app uses Supabase Auth with `signInWithOAuth({ provider: "google" })`.
- The redirect target in the app is the account page.
- If you also want email confirmation to flow correctly, keep the `emailRedirectTo` in the sign-up flow pointing to `/login` or your chosen confirmed page.
