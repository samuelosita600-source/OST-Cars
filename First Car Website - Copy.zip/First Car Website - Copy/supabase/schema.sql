-- OST Luxury Cars Supabase schema
-- Run this in the Supabase SQL editor for the live project.

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_type t
    JOIN pg_namespace n ON n.oid = t.typnamespace
    WHERE t.typname = 'app_role' AND n.nspname = 'public'
  ) THEN
    CREATE TYPE public.app_role AS ENUM ('admin', 'customer');
  END IF;
END $$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text,
  phone text,
  preferred_contact text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.user_roles
    where user_id = _user_id and role = _role
  );
$$;

create table if not exists public.vehicles (
  id uuid primary key default gen_random_uuid(),
  ref text not null unique,
  slug text not null unique,
  brand text not null,
  model text not null,
  year integer not null,
  price numeric(12,2) not null default 0,
  body_type text not null,
  mileage integer not null default 0,
  transmission text not null default 'Automatic',
  fuel text not null default 'Petrol',
  engine text not null default '',
  power text not null default '',
  drivetrain text not null default 'AWD',
  exterior_colour text not null default 'Obsidian Black',
  interior_colour text not null default 'Black Nappa Leather',
  images text[] not null default '{}',
  location text not null default 'Abuja',
  condition text not null default 'Foreign Used',
  features text[] not null default '{}',
  availability text not null default 'Available',
  vin text not null default '',
  inspection text not null default 'Inspected',
  featured boolean not null default false,
  date_added timestamptz not null default now(),
  seats integer not null default 5,
  acceleration text not null default '',
  description text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.enquiries (
  id uuid primary key default gen_random_uuid(),
  vehicle_id uuid references public.vehicles(id) on delete set null,
  user_id uuid references auth.users(id) on delete set null,
  kind text not null default 'Interest',
  name text not null,
  email text not null,
  phone text,
  message text,
  status text not null default 'New',
  admin_notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.favorites (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  vehicle_id uuid not null references public.vehicles(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (user_id, vehicle_id)
);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', '')
  )
  on conflict (id) do update
    set email = excluded.email,
        full_name = coalesce(excluded.full_name, public.profiles.full_name),
        updated_at = now();

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.update_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists profiles_updated_at on public.profiles;
create trigger profiles_updated_at
before update on public.profiles
for each row execute procedure public.update_updated_at();

drop trigger if exists vehicles_updated_at on public.vehicles;
create trigger vehicles_updated_at
before update on public.vehicles
for each row execute procedure public.update_updated_at();

create index if not exists profiles_email_idx on public.profiles (email);
create index if not exists vehicles_body_type_idx on public.vehicles (body_type);
create index if not exists vehicles_featured_idx on public.vehicles (featured);
create index if not exists vehicles_slug_idx on public.vehicles (slug);
create index if not exists user_roles_user_id_idx on public.user_roles (user_id);
create index if not exists enquiries_user_id_idx on public.enquiries (user_id);
create index if not exists enquiries_created_at_idx on public.enquiries (created_at desc);
create index if not exists favorites_user_id_idx on public.favorites (user_id);

alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.vehicles enable row level security;
alter table public.enquiries enable row level security;
alter table public.favorites enable row level security;

drop policy if exists "Profiles are readable by their owner" on public.profiles;
create policy "Profiles are readable by their owner"
on public.profiles for select
using (id = auth.uid());

drop policy if exists "Profiles are editable by their owner" on public.profiles;
create policy "Profiles are editable by their owner"
on public.profiles for update
using (id = auth.uid())
with check (id = auth.uid());

drop policy if exists "Users can read their own roles" on public.user_roles;
create policy "Users can read their own roles"
on public.user_roles for select
using (user_id = auth.uid());

drop policy if exists "Vehicles are publicly readable" on public.vehicles;
create policy "Vehicles are publicly readable"
on public.vehicles for select
using (true);

drop policy if exists "Admins can insert vehicles" on public.vehicles;
create policy "Admins can insert vehicles"
on public.vehicles for insert
with check (public.has_role(auth.uid(), 'admin'));

drop policy if exists "Admins can update vehicles" on public.vehicles;
create policy "Admins can update vehicles"
on public.vehicles for update
using (public.has_role(auth.uid(), 'admin'))
with check (public.has_role(auth.uid(), 'admin'));

drop policy if exists "Admins can delete vehicles" on public.vehicles;
create policy "Admins can delete vehicles"
on public.vehicles for delete
using (public.has_role(auth.uid(), 'admin'));

drop policy if exists "Anyone can submit enquiries" on public.enquiries;
create policy "Anyone can submit enquiries"
on public.enquiries for insert
with check (user_id is null or user_id = auth.uid());

drop policy if exists "Users and admins can read enquiries" on public.enquiries;
create policy "Users and admins can read enquiries"
on public.enquiries for select
using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Admins can update enquiries" on public.enquiries;
create policy "Admins can update enquiries"
on public.enquiries for update
using (public.has_role(auth.uid(), 'admin'))
with check (public.has_role(auth.uid(), 'admin'));

drop policy if exists "Users can read their favorites" on public.favorites;
create policy "Users can read their favorites"
on public.favorites for select
using (user_id = auth.uid());

drop policy if exists "Users can add their favorites" on public.favorites;
create policy "Users can add their favorites"
on public.favorites for insert
with check (user_id = auth.uid());

drop policy if exists "Users can remove their favorites" on public.favorites;
create policy "Users can remove their favorites"
on public.favorites for delete
using (user_id = auth.uid());

insert into storage.buckets (id, name, public)
values ('vehicle-images', 'vehicle-images', false)
on conflict (id) do nothing;

drop policy if exists "Admins can read vehicle images" on storage.objects;
create policy "Admins can read vehicle images"
on storage.objects for select
using (bucket_id = 'vehicle-images' and public.has_role(auth.uid(), 'admin'));

drop policy if exists "Admins can upload vehicle images" on storage.objects;
create policy "Admins can upload vehicle images"
on storage.objects for insert
with check (bucket_id = 'vehicle-images' and public.has_role(auth.uid(), 'admin'));

drop policy if exists "Admins can update vehicle images" on storage.objects;
create policy "Admins can update vehicle images"
on storage.objects for update
using (bucket_id = 'vehicle-images' and public.has_role(auth.uid(), 'admin'))
with check (bucket_id = 'vehicle-images' and public.has_role(auth.uid(), 'admin'));

drop policy if exists "Admins can delete vehicle images" on storage.objects;
create policy "Admins can delete vehicle images"
on storage.objects for delete
using (bucket_id = 'vehicle-images' and public.has_role(auth.uid(), 'admin'));

-- Grant admin to your account after the user exists in auth.users.
insert into public.user_roles (user_id, role)
select id, 'admin'::public.app_role
from auth.users
where lower(email) = lower('samuelosita600@gmail.com')
on conflict (user_id, role) do nothing;

-- Example vehicle row for testing the inventory screen.
insert into public.vehicles (
  ref, slug, brand, model, year, price, body_type, mileage, transmission, fuel,
  engine, power, drivetrain, exterior_colour, interior_colour, images, location,
  condition, features, availability, vin, inspection, featured, seats, acceleration,
  description
)
values (
  'OST-001',
  '2025-bmw-x5-m50d',
  'BMW',
  'X5 M50d',
  2025,
  42000000,
  'SUV',
  12000,
  'Automatic',
  'Diesel',
  '3.0L TwinPower Turbo I6',
  '400 hp',
  'AWD',
  'Alpine White',
  'Black Nappa Leather',
  array['https://images.unsplash.com/photo-1553440569-bcc63803a83d?auto=format&fit=crop&w=1200&q=80'],
  'Abuja',
  'Foreign Used',
  array['Driver Assistance', 'Panoramic Roof', 'Heated Seats'],
  'Available',
  'WBA8D3C5X5K123456',
  'Inspected',
  true,
  5,
  '5.2s 0-100 km/h',
  'Luxury SUV with a refined cabin, strong performance and the comfort expected from a flagship BMW.'
)
on conflict (ref) do nothing;
