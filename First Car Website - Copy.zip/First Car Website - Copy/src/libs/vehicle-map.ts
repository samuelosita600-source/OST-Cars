import { fallbackImages, type Availability, type BodyType, type Vehicle } from "@/data/vehicles";

export interface VehicleRow {
  id: string;
  ref: string;
  slug: string;
  brand: string;
  model: string;
  year: number;
  price: number;
  body_type: string;
  mileage: number;
  transmission: string;
  fuel: string;
  engine: string;
  power: string;
  drivetrain: string;
  exterior_colour: string;
  interior_colour: string;
  images: string[];
  location: string;
  condition: string;
  features: string[];
  availability: string;
  vin: string;
  inspection: string;
  featured: boolean;
  date_added: string;
  seats: number;
  acceleration: string;
  description: string | null;
}

export const VEHICLE_COLUMNS =
  "id, ref, slug, brand, model, year, price, body_type, mileage, transmission, fuel, engine, power, drivetrain, exterior_colour, interior_colour, images, location, condition, features, availability, vin, inspection, featured, date_added, seats, acceleration, description";

export function mapVehicle(row: VehicleRow): Vehicle {
  const images = row.images?.length ? row.images : fallbackImages(row.body_type);
  return {
    id: row.id,
    ref: row.ref,
    slug: row.slug,
    brand: row.brand,
    model: row.model,
    year: row.year,
    price: Number(row.price),
    bodyType: row.body_type as BodyType,
    mileage: row.mileage,
    transmission: row.transmission,
    fuel: row.fuel,
    engine: row.engine,
    power: row.power,
    drivetrain: row.drivetrain,
    exteriorColour: row.exterior_colour,
    interiorColour: row.interior_colour,
    images,
    location: row.location,
    condition: row.condition,
    features: row.features ?? [],
    availability: row.availability as Availability,
    vin: row.vin,
    inspection: row.inspection,
    featured: row.featured,
    dateAdded: row.date_added,
    seats: row.seats,
    acceleration: row.acceleration,
    description: row.description,
  };
}
