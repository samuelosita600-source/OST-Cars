import { useCallback, useSyncExternalStore } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

/**
 * Compare list stays on the device (a transient shopping tool).
 * Saved cars (favorites) persist in the database for signed-in customers and
 * fall back to this device for guests.
 */

type StoreKey = "ost:favorites" | "ost:compare";

const listeners = new Set<() => void>();
const cache = new Map<StoreKey, string[]>();

function read(key: StoreKey): string[] {
  if (cache.has(key)) return cache.get(key) as string[];
  let value: string[] = [];
  if (typeof window !== "undefined") {
    try {
      const raw = window.localStorage.getItem(key);
      if (raw) value = JSON.parse(raw) as string[];
    } catch {
      value = [];
    }
  }
  cache.set(key, value);
  return value;
}

function write(key: StoreKey, value: string[]) {
  cache.set(key, value);
  if (typeof window !== "undefined") {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch {
      /* storage unavailable — state stays in-memory */
    }
  }
  listeners.forEach((l) => l());
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

const EMPTY: string[] = [];

function useList(key: StoreKey) {
  const items = useSyncExternalStore(
    subscribe,
    () => read(key),
    () => EMPTY,
  );

  const toggle = useCallback(
    (id: string, limit?: number) => {
      const current = read(key);
      if (current.includes(id)) {
        write(
          key,
          current.filter((x) => x !== id),
        );
        return false;
      }
      if (limit && current.length >= limit) {
        write(key, [...current.slice(1), id]);
        return true;
      }
      write(key, [...current, id]);
      return true;
    },
    [key],
  );

  const remove = useCallback(
    (id: string) => {
      write(
        key,
        read(key).filter((x) => x !== id),
      );
    },
    [key],
  );

  const clear = useCallback(() => write(key, []), [key]);

  return { items, toggle, remove, clear };
}

export function useFavorites() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const local = useList("ost:favorites");

  const { data: remote } = useQuery({
    queryKey: ["favorites", user?.id ?? "guest"],
    enabled: Boolean(user),
    queryFn: async () => {
      const { data, error } = await supabase.from("favorites").select("vehicle_id");
      if (error) throw error;
      return data.map((r) => r.vehicle_id);
    },
  });

  const mutate = useMutation({
    mutationFn: async ({ id, add }: { id: string; add: boolean }) => {
      if (!user) return;
      if (add) {
        const { error } = await supabase.from("favorites").insert({ user_id: user.id, vehicle_id: id });
        if (error) throw error;
      } else {
        const { error } = await supabase.from("favorites").delete().eq("vehicle_id", id).eq("user_id", user.id);
        if (error) throw error;
      }
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["favorites"] }),
  });

  const clearAll = useMutation({
    mutationFn: async () => {
      if (!user) return;
      const { error } = await supabase.from("favorites").delete().eq("user_id", user.id);
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["favorites"] }),
  });

  if (!user) {
    return {
      favorites: local.items,
      persisted: false,
      toggleFavorite: (id: string) => local.toggle(id),
      removeFavorite: local.remove,
      clearFavorites: local.clear,
    };
  }

  const favorites = remote ?? [];
  return {
    favorites,
    persisted: true,
    toggleFavorite: (id: string) => mutate.mutate({ id, add: !favorites.includes(id) }),
    removeFavorite: (id: string) => mutate.mutate({ id, add: false }),
    clearFavorites: () => clearAll.mutate(),
  };
}

export function useCompare() {
  const { items, toggle, remove, clear } = useList("ost:compare");
  return {
    compare: items,
    toggleCompare: (id: string) => toggle(id, 4),
    removeCompare: remove,
    clearCompare: clear,
  };
}
