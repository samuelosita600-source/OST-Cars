import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { mapVehicle, VEHICLE_COLUMNS, type VehicleRow } from "@/libs/vehicle-map";
import { slugify } from "@/libs/format";
import type { Vehicle } from "@/data/vehicles";

const TEN_YEARS = 60 * 60 * 24 * 365 * 10;

export interface VehicleInput {
  ref: string;
  brand: string;
  model: string;
  year: number;
  price: number;
  body_type: string;
  mileage: number;
  transmission: string;
  fuel: string;
  engine: string;
  power: string;
  drivetrain: string;
  exterior_colour: string;
  interior_colour: string;
  location: string;
  condition: string;
  features: string[];
  availability: string;
  vin: string;
  inspection: string;
  featured: boolean;
  seats: number;
  acceleration: string;
  description: string;
  images: string[];
}

export function useAllVehicles() {
  return useQuery({
    queryKey: ["vehicles"],
    queryFn: async (): Promise<Vehicle[]> => {
      const { data, error } = await supabase
        .from("vehicles")
        .select(VEHICLE_COLUMNS)
        .order("date_added", { ascending: false })
        .limit(500);
      if (error) throw error;
      return (data as unknown as VehicleRow[]).map(mapVehicle);
    },
  });
}

/** Uploads one photo to the vehicle-images bucket and returns a long-lived URL. */
export async function uploadVehicleImage(file: File, ref: string, angle: string): Promise<string> {
  const ext = file.name.split(".").pop() ?? "jpg";
  const path = `${slugify(ref || "vehicle")}/${slugify(angle)}-${Date.now()}.${ext}`;
  const { error } = await supabase.storage.from("vehicle-images").upload(path, file, { upsert: true });
  if (error) throw error;
  const { data, error: signError } = await supabase.storage.from("vehicle-images").createSignedUrl(path, TEN_YEARS);
  if (signError || !data) throw signError ?? new Error("Could not create image URL");
  return data.signedUrl;
}

export function useVehicleMutations() {
  const queryClient = useQueryClient();
  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["vehicles"] });

  const create = useMutation({
    mutationFn: async (input: VehicleInput) => {
      const slug = slugify(`${input.brand} ${input.model} ${input.year} ${input.ref}`);
      const { error } = await supabase.from("vehicles").insert({ ...input, slug });
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  const update = useMutation({
    mutationFn: async ({ id, input }: { id: string; input: VehicleInput }) => {
      const { error } = await supabase.from("vehicles").update(input).eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("vehicles").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  return { create, update, remove };
}

export interface Enquiry {
  id: string;
  vehicle_id: string | null;
  user_id: string | null;
  kind: string;
  name: string;
  email: string;
  phone: string | null;
  message: string | null;
  status: string;
  created_at: string;
}

export function useEnquiries(enabled: boolean) {
  return useQuery({
    queryKey: ["enquiries"],
    enabled,
    queryFn: async (): Promise<Enquiry[]> => {
      const { data, error } = await supabase
        .from("enquiries")
        .select("id, vehicle_id, user_id, kind, name, email, phone, message, status, created_at")
        .order("created_at", { ascending: false })
        .limit(300);
      if (error) throw error;
      return data as Enquiry[];
    },
  });
}

export function useEnquiryStatus() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase.from("enquiries").update({ status }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["enquiries"] }),
  });
}

export interface EnquiryInput {
  vehicle_id?: string | null;
  kind: string;
  name: string;
  email: string;
  phone?: string | null;
  message?: string | null;
}

export async function submitEnquiry(input: EnquiryInput, userId?: string | null) {
  const { error } = await supabase.from("enquiries").insert({ ...input, user_id: userId ?? null });
  if (error) throw error;
}
