export function formatNaira(value: number): string {
  return `₦${Math.round(value).toLocaleString("en-NG")}`;
}

export function formatNairaShort(value: number): string {
  if (value >= 1_000_000_000) return `₦${(value / 1_000_000_000).toFixed(2)}B`;
  if (value >= 1_000_000) return `₦${Math.round(value / 1_000_000)}M`;
  return formatNaira(value);
}

export function formatMileage(km: number): string {
  return `${km.toLocaleString("en-NG")} km`;
}

export function slugify(input: string): string {
  return input
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

/** Monthly payment estimate (annuity). rate = annual % */
export function monthlyPayment(principal: number, annualRatePct: number, months: number): number {
  if (principal <= 0 || months <= 0) return 0;
  const r = annualRatePct / 100 / 12;
  if (r === 0) return principal / months;
  return (principal * r) / (1 - Math.pow(1 + r, -months));
}

export const WHATSAPP_NUMBER = "2349138049925";
export const CONTACT_PHONE = "09138049925";
export const CONTACT_PHONE_INTL = "+234 913 804 9925";
export const CONTACT_EMAIL = "samuelosita600@gmail.com";
export const SHOWROOM_ADDRESS = "Kugbo, Abuja, Nigeria";

export function whatsappLink(message: string): string {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}
