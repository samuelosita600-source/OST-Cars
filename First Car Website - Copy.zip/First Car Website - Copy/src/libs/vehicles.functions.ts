import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import { mapVehicle, VEHICLE_COLUMNS, type VehicleRow } from "@/libs/vehicle-map";

function publicClient() {
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"]!;
  return createClient(process.env["SUPABASE_URL"]!, key, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
    global: {
      fetch: (input: RequestInfo | URL, init?: RequestInit) => {
        const h = new Headers(init?.headers);
        if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
        h.set("apikey", key);
        return fetch(input, { ...init, headers: h });
      },
    },
  });
}

export const listVehicles = createServerFn({ method: "GET" }).handler(async () => {
  const supabase = publicClient();

  try {
    const { data, error } = await supabase
      .from("vehicles")
      .select(VEHICLE_COLUMNS)
      .order("date_added", { ascending: false })
      .limit(500);

    if (error) {
      if (error.code === "42P01") {
        console.warn("[vehicles] public.vehicles table not found; returning empty list.");
        return [];
      }
      throw new Error(error.message);
    }

    return ((data ?? []) as unknown as VehicleRow[]).map(mapVehicle);
  } catch (error) {
    console.warn("[vehicles] inventory load failed:", error instanceof Error ? error.message : error);
    return [];
  }
});

export const getVehicleBySlug = createServerFn({ method: "GET" })
  .validator((input: { slug: string }) => z.object({ slug: z.string().min(1).max(200) }).parse(input))
  .handler(async ({ data }) => {
    const supabase = publicClient();

    try {
      const { data: row, error } = await supabase
        .from("vehicles")
        .select(VEHICLE_COLUMNS)
        .eq("slug", data.slug)
        .maybeSingle();

      if (error) {
        if (error.code === "42P01") {
          console.warn("[vehicles] public.vehicles table not found; vehicle lookup unavailable.");
          return null;
        }
        throw new Error(error.message);
      }

      if (!row) return null;
      const vehicle = mapVehicle(row as unknown as VehicleRow);
      const { data: similar } = await supabase
        .from("vehicles")
        .select(VEHICLE_COLUMNS)
        .eq("body_type", vehicle.bodyType)
        .neq("id", vehicle.id)
        .limit(3);
      return { vehicle, similar: ((similar ?? []) as unknown as VehicleRow[]).map(mapVehicle) };
    } catch (error) {
      console.warn("[vehicles] single vehicle lookup failed:", error instanceof Error ? error.message : error);
      return null;
    }
  });
