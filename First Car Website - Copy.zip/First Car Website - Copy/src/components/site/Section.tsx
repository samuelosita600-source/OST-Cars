import type { ReactNode } from "react";
import { useRevealRoot } from "@/hooks/use-reveal";

interface SectionProps {
  eyebrow?: string;
  title?: ReactNode;
  lead?: string;
  children: ReactNode;
  className?: string;
  id?: string;
  align?: "left" | "center";
}

export function Section({ eyebrow, title, lead, children, className = "", id, align = "left" }: SectionProps) {
  const ref = useRevealRoot<HTMLElement>();
  return (
    <section ref={ref} id={id} className={`relative py-20 sm:py-28 ${className}`}>
      <div className="mx-auto max-w-7xl px-5 sm:px-6">
        {(eyebrow || title || lead) && (
          <header className={`reveal mb-12 ${align === "center" ? "mx-auto max-w-2xl text-center" : "max-w-2xl"}`}>
            {eyebrow && <p className="eyebrow">{eyebrow}</p>}
            {title && (
              <h2 className="font-display mt-4 text-3xl leading-[1.12] sm:text-4xl lg:text-5xl">
                <span className="text-chrome-gradient">{title}</span>
              </h2>
            )}
            {lead && <p className="mt-4 text-sm leading-relaxed text-muted-foreground sm:text-base">{lead}</p>}
          </header>
        )}
        {children}
      </div>
    </section>
  );
}

export function PageHero({
  eyebrow,
  title,
  lead,
  children,
}: {
  eyebrow: string;
  title: string;
  lead?: string;
  children?: ReactNode;
}) {
  return (
    <section className="relative overflow-hidden border-b border-border bg-abyss-gradient pt-32 pb-16 sm:pt-40 sm:pb-20">
      <div
        className="pointer-events-none absolute -top-32 left-1/2 h-72 w-[36rem] -translate-x-1/2 rounded-full opacity-20 blur-[120px]"
        style={{ backgroundImage: "var(--gradient-pearl)" }}
      />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-6">
        <p className="eyebrow">{eyebrow}</p>
        <h1 className="font-display mt-4 max-w-3xl text-4xl leading-[1.06] sm:text-6xl">
          <span className="text-chrome-gradient">{title}</span>
        </h1>
        {lead && <p className="mt-5 max-w-xl text-sm leading-relaxed text-muted-foreground sm:text-base">{lead}</p>}
        {children && <div className="mt-8">{children}</div>}
      </div>
    </section>
  );
}
