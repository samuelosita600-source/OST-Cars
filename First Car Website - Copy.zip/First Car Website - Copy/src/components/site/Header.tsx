import { Link, useRouterState } from "@tanstack/react-router";
import { Heart, GitCompareArrows, Menu, X, Phone } from "lucide-react";
import { useEffect, useState } from "react";
import { Monogram, WordMark } from "@/components/brand/Monogram";
import { useAuth } from "@/lib/auth";
import { useCompare, useFavorites } from "@/lib/store";
import { whatsappLink } from "@/lib/format";

const NAV = [
  { to: "/inventory", label: "Collection" },
  { to: "/services", label: "Services" },
  { to: "/financing", label: "Financing" },
  { to: "/sell", label: "Sell / Trade-In" },
  { to: "/about", label: "About" },
  { to: "/blog", label: "Journal" },
  { to: "/contact", label: "Contact" },
] as const;

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { favorites } = useFavorites();
  const { compare } = useCompare();
  const { user, isAdmin } = useAuth();
  const accountTo = user ? (isAdmin ? "/admin" : "/account") : "/login";
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setOpen(false), [pathname]);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled ? "glass-panel border-b border-border" : "border-b border-transparent bg-transparent"
      }`}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 sm:h-20 sm:px-6">
        <Link to="/" className="flex items-center gap-3" aria-label="OST Luxury Cars — home">
          <Monogram className="h-9 w-9 sm:h-10 sm:w-10" />
          <span className="flex flex-col">
            <WordMark className="text-base sm:text-lg" />
            <span className="text-[0.55rem] tracking-[0.3em] text-muted-foreground">CHOOSE UR CAR WISELY</span>
          </span>
        </Link>

        <nav className="ml-auto hidden items-center gap-7 lg:flex" aria-label="Main navigation">
          {NAV.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="text-[0.72rem] tracking-[0.18em] uppercase text-muted-foreground transition-colors hover:text-foreground"
              activeProps={{ className: "text-foreground" }}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-1 lg:ml-4">
          <Link
            to="/favorites"
            aria-label={`Saved cars (${favorites.length})`}
            className="relative rounded-full p-2.5 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
          >
            <Heart className="h-[18px] w-[18px]" />
            {favorites.length > 0 && (
              <span className="absolute -top-0.5 -right-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-primary px-1 text-[0.6rem] font-semibold text-primary-foreground">
                {favorites.length}
              </span>
            )}
          </Link>
          <Link
            to="/compare"
            aria-label={`Compare cars (${compare.length})`}
            className="relative rounded-full p-2.5 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
          >
            <GitCompareArrows className="h-[18px] w-[18px]" />
            {compare.length > 0 && (
              <span className="absolute -top-0.5 -right-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-primary px-1 text-[0.6rem] font-semibold text-primary-foreground">
                {compare.length}
              </span>
            )}
          </Link>
          <a
            href={whatsappLink("Hello OST Luxury Cars, I would like to speak with a concierge.")}
            target="_blank"
            rel="noopener noreferrer"
            className="sheen-hover hidden items-center gap-2 rounded-full border border-border px-4 py-2 text-[0.7rem] tracking-[0.16em] uppercase text-foreground transition-colors hover:border-pearl md:inline-flex"
          >
            <Phone className="h-3.5 w-3.5" />
            Concierge
          </a>
          <Link
            to={accountTo}
            className="hidden rounded-full bg-secondary px-4 py-2 text-[0.7rem] tracking-[0.16em] uppercase text-secondary-foreground transition-colors hover:bg-accent sm:inline-block"
          >
            {user ? (isAdmin ? "Admin" : "My account") : "Sign in"}
          </Link>
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-label={open ? "Close menu" : "Open menu"}
            className="rounded-full p-2.5 text-foreground lg:hidden"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {open && (
        <nav className="glass-panel border-t border-border lg:hidden" aria-label="Mobile navigation">
          <ul className="mx-auto max-w-7xl px-4 py-3">
            {[...NAV, { to: "/test-drive", label: "Book a Test Drive" }, { to: accountTo, label: user ? (isAdmin ? "Admin" : "My account") : "Sign in" }].map(
              (item) => (
                <li key={item.to}>
                  <Link
                    to={item.to}
                    className="block border-b border-border/60 py-3.5 text-sm tracking-[0.14em] uppercase text-muted-foreground"
                    activeProps={{ className: "text-foreground" }}
                  >
                    {item.label}
                  </Link>
                </li>
              ),
            )}
          </ul>
        </nav>
      )}
    </header>
  );
}
