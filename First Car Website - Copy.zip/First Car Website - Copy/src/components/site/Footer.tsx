import { Link } from "@tanstack/react-router";
import { Instagram, Facebook, Twitter, Mail, MapPin, MessageCircle } from "lucide-react";
import { Monogram, WordMark } from "@/components/brand/Monogram";
import { whatsappLink, CONTACT_EMAIL, CONTACT_PHONE, SHOWROOM_ADDRESS } from "@/lib/format";

const COLUMNS = [
  {
    title: "Explore",
    links: [
      { to: "/inventory", label: "Full Collection" },
      { to: "/compare", label: "Compare Cars" },
      { to: "/favorites", label: "Saved Cars" },
      { to: "/blog", label: "Journal & Guides" },
    ],
  },
  {
    title: "Buy & Own",
    links: [
      { to: "/financing", label: "Financing" },
      { to: "/test-drive", label: "Book a Test Drive" },
      { to: "/sell", label: "Sell or Trade-In" },
      { to: "/services", label: "Services" },
    ],
  },
  {
    title: "Company",
    links: [
      { to: "/about", label: "About OST" },
      { to: "/contact", label: "Contact" },
      { to: "/login", label: "Customer Account" },
      { to: "/admin", label: "Admin Dashboard" },
    ],
  },
] as const;

export function Footer() {
  return (
    <footer className="border-t border-border bg-abyss-gradient">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_repeat(3,1fr)]">
          <div>
            <Link to="/" className="flex items-center gap-3">
              <Monogram className="h-11 w-11" />
              <span className="flex flex-col">
                <WordMark className="text-lg" />
                <span className="text-[0.55rem] tracking-[0.3em] text-muted-foreground">CHOOSE UR CAR WISELY</span>
              </span>
            </Link>
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-muted-foreground">
              A curated luxury automotive house serving Nigeria — sourcing, inspection, import support and concierge
              delivery nationwide.
            </p>
            <div className="mt-6 flex items-center gap-3">
              {[
                { Icon: Instagram, label: "Instagram" },
                { Icon: Facebook, label: "Facebook" },
                { Icon: Twitter, label: "X" },
              ].map(({ Icon, label }) => (
                <a
                  key={label}
                  href="#"
                  aria-label={`OST Luxury Cars on ${label}`}
                  className="rounded-full border border-border p-2.5 text-muted-foreground transition-colors hover:border-pearl hover:text-foreground"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {COLUMNS.map((col) => (
            <div key={col.title}>
              <h3 className="eyebrow">{col.title}</h3>
              <ul className="mt-5 space-y-3">
                {col.links.map((l) => (
                  <li key={l.to}>
                    <Link to={l.to} className="text-sm text-muted-foreground transition-colors hover:text-foreground">
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="hairline my-12" />

        <div className="grid gap-8 text-sm text-muted-foreground sm:grid-cols-3">
          <div>
            <h4 className="eyebrow mb-3">Showroom</h4>
            <p className="flex items-start gap-2">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0" />
              <span>
                {SHOWROOM_ADDRESS}
                <br />
                Service coverage: Abuja, Lagos, Port Harcourt & nationwide delivery.
              </span>
            </p>
          </div>
          <div>
            <h4 className="eyebrow mb-3">Talk to us</h4>
            <p className="flex items-center gap-2">
              <MessageCircle className="h-4 w-4" />
              <a
                href={whatsappLink("Hello OST Luxury Cars, I have an enquiry.")}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-foreground"
              >
                WhatsApp concierge
              </a>
            </p>
            <p className="mt-2 flex items-center gap-2">
              <Mail className="h-4 w-4" />
              <a href={`mailto:${CONTACT_EMAIL}`} className="hover:text-foreground">
                {CONTACT_EMAIL}
              </a>
            </p>
            <p className="mt-2">
              Phone:{" "}
              <a href={`tel:${CONTACT_PHONE}`} className="hover:text-foreground">
                {CONTACT_PHONE}
              </a>
            </p>
          </div>
          <div>
            <h4 className="eyebrow mb-3">Hours</h4>
            <p>Mon – Fri: 9:00am – 6:00pm</p>
            <p>Saturday: 10:00am – 5:00pm</p>
            <p>Sunday: By appointment</p>
          </div>
        </div>

        <div className="mt-12 flex flex-col gap-3 border-t border-border pt-6 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} OST Luxury Cars. All rights reserved.</p>
          <p className="flex flex-wrap gap-5">
            <span>Privacy Policy</span>
            <span>Terms of Use</span>
            <span>Vehicle Disclaimer</span>
          </p>
        </div>
        <p className="mt-6 text-[0.7rem] leading-relaxed text-muted-foreground/70">
          Prices, availability and specifications are indicative and subject to confirmation. Finance figures shown
          anywhere on this site are estimates only and are subject to lender assessment and approval.
        </p>
      </div>
    </footer>
  );
}
