import type { ReactNode } from "react";

export function Field({
  label,
  children,
  hint,
}: {
  label: string;
  children: ReactNode;
  hint?: string;
}) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="text-[0.6rem] tracking-[0.22em] uppercase text-muted-foreground">{label}</span>
      {children}
      {hint && <span className="text-[0.68rem] text-muted-foreground">{hint}</span>}
    </label>
  );
}

export const inputClass =
  "h-11 w-full rounded-md border border-input bg-secondary/50 px-3 text-sm text-foreground placeholder:text-muted-foreground/70";
export const textareaClass =
  "min-h-28 w-full rounded-md border border-input bg-secondary/50 p-3 text-sm text-foreground placeholder:text-muted-foreground/70";
