import { useNavigate } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { BODY_TYPES, BRANDS } from "@/data/vehicles";

const BUDGETS = [
  { label: "Any budget", value: "" },
  { label: "Under ₦80M", value: "80000000" },
  { label: "Under ₦150M", value: "150000000" },
  { label: "Under ₦300M", value: "300000000" },
  { label: "Under ₦600M", value: "600000000" },
];

export function QuickSearch() {
  const navigate = useNavigate();
  const [brand, setBrand] = useState("");
  const [body, setBody] = useState("");
  const [max, setMax] = useState("");

  return (
    <section className="relative z-20 -mt-1 border-y border-border bg-abyss-gradient py-8">
      <div className="mx-auto max-w-7xl px-5 sm:px-6">
        <form
          className="glass-panel grid gap-3 rounded-lg p-4 sm:grid-cols-2 lg:grid-cols-[1fr_1fr_1fr_auto]"
          onSubmit={(e) => {
            e.preventDefault();
            void navigate({
              to: "/inventory",
              search: {
                brand: brand || undefined,
                body: body || undefined,
                max: max ? Number(max) : undefined,
              },
            });
          }}
        >
          <label className="flex flex-col gap-1.5">
            <span className="text-[0.6rem] tracking-[0.22em] uppercase text-muted-foreground">Brand</span>
            <select
              value={brand}
              onChange={(e) => setBrand(e.target.value)}
              className="h-11 rounded-md border border-input bg-secondary/60 px-3 text-sm text-foreground"
            >
              <option value="">All brands</option>
              {BRANDS.map((b) => (
                <option key={b} value={b}>
                  {b}
                </option>
              ))}
            </select>
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="text-[0.6rem] tracking-[0.22em] uppercase text-muted-foreground">Body type</span>
            <select
              value={body}
              onChange={(e) => setBody(e.target.value)}
              className="h-11 rounded-md border border-input bg-secondary/60 px-3 text-sm text-foreground"
            >
              <option value="">All types</option>
              {BODY_TYPES.map((b) => (
                <option key={b} value={b}>
                  {b}
                </option>
              ))}
            </select>
          </label>
          <label className="flex flex-col gap-1.5">
            <span className="text-[0.6rem] tracking-[0.22em] uppercase text-muted-foreground">Budget</span>
            <select
              value={max}
              onChange={(e) => setMax(e.target.value)}
              className="h-11 rounded-md border border-input bg-secondary/60 px-3 text-sm text-foreground"
            >
              {BUDGETS.map((b) => (
                <option key={b.label} value={b.value}>
                  {b.label}
                </option>
              ))}
            </select>
          </label>
          <div className="flex items-end">
            <Button type="submit" variant="pearl" size="lg" className="w-full lg:w-auto">
              <Search className="h-4 w-4" />
              Search
            </Button>
          </div>
        </form>
      </div>
    </section>
  );
}
