import { useState } from "react";
import { X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Field, inputClass, textareaClass } from "@/components/site/FormBits";
import { useAuth } from "@/libs/auth";
import { submitEnquiry } from "@/libs/vehicles-admin";
import type { Vehicle } from "@/data/vehicles";

interface Props {
  vehicle?: Vehicle | null;
  kind?: string;
  label?: string;
  variant?: "hero" | "chrome" | "secondary";
  className?: string;
}

/** "I'm Interested" — logs a real enquiry that appears in the admin dashboard. */
export function EnquiryDialog({ vehicle, kind = "Interest", label = "I'm Interested", variant = "hero", className }: Props) {
  const [open, setOpen] = useState(false);
  const { user, profile } = useAuth();
  const [busy, setBusy] = useState(false);

  return (
    <>
      <Button variant={variant} size="lg" className={className} onClick={() => setOpen(true)}>
        {label}
      </Button>

      {open && (
        <div className="fixed inset-0 z-[90] flex items-end justify-center sm:items-center">
          <button type="button" aria-label="Close" className="absolute inset-0 bg-abyss/85" onClick={() => setOpen(false)} />
          <form
            className="glass-panel relative m-0 w-full max-w-lg space-y-4 rounded-t-2xl p-7 sm:m-4 sm:rounded-lg"
            onSubmit={async (e) => {
              e.preventDefault();
              const form = new FormData(e.currentTarget);
              setBusy(true);
              try {
                await submitEnquiry(
                  {
                    vehicle_id: vehicle?.id ?? null,
                    kind,
                    name: String(form.get("name") ?? ""),
                    email: String(form.get("email") ?? ""),
                    phone: String(form.get("phone") ?? ""),
                    message: String(form.get("message") ?? ""),
                  },
                  user?.id,
                );
                toast.success("Enquiry sent", { description: "A concierge will be in touch shortly." });
                setOpen(false);
              } catch (err) {
                toast.error("Could not send enquiry", { description: err instanceof Error ? err.message : undefined });
              } finally {
                setBusy(false);
              }
            }}
          >
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="eyebrow">{kind}</p>
                <h2 className="font-display mt-1 text-2xl">
                  {vehicle ? `${vehicle.year} ${vehicle.brand} ${vehicle.model}` : "Speak to a concierge"}
                </h2>
              </div>
              <button type="button" onClick={() => setOpen(false)} aria-label="Close" className="p-1 text-muted-foreground">
                <X className="h-5 w-5" />
              </button>
            </div>

            <Field label="Full name">
              <input name="name" required defaultValue={profile?.full_name ?? ""} className={inputClass} placeholder="Your name" />
            </Field>
            <Field label="Email">
              <input name="email" required type="email" defaultValue={profile?.email ?? user?.email ?? ""} className={inputClass} placeholder="you@example.com" />
            </Field>
            <Field label="Phone / WhatsApp">
              <input name="phone" type="tel" defaultValue={profile?.phone ?? ""} className={inputClass} placeholder="080 0000 0000" />
            </Field>
            <Field label="Message">
              <textarea
                name="message"
                rows={3}
                className={textareaClass}
                defaultValue={vehicle ? `I would like more details on ${vehicle.ref} — ${vehicle.year} ${vehicle.brand} ${vehicle.model}.` : ""}
              />
            </Field>
            <Button type="submit" variant="hero" size="xl" className="w-full" disabled={busy}>
              {busy ? "Sending…" : "Send enquiry"}
            </Button>
          </form>
        </div>
      )}
    </>
  );
}
