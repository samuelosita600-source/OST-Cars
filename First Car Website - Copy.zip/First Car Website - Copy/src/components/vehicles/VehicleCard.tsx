import { Link } from "@tanstack/react-router";
import { Heart, GitCompareArrows, MessageCircle, Gauge, Fuel, Calendar, MapPin } from "lucide-react";
import { formatMileage, formatNaira, whatsappLink } from "@/lib/format";
import { useCompare, useFavorites } from "@/lib/store";
import type { Vehicle } from "@/data/vehicles";

function StatusChip({ vehicle }: { vehicle: Vehicle }) {
  const tone =
    vehicle.availability === "Available"
      ? "border-success/50 text-success"
      : vehicle.availability === "Sold"
        ? "border-destructive/50 text-destructive"
        : "border-warning/50 text-warning";
  return (
    <span className={`rounded-full border px-2.5 py-1 text-[0.6rem] tracking-[0.18em] uppercase ${tone}`}>
      {vehicle.availability}
    </span>
  );
}

interface CardProps {
  vehicle: Vehicle;
  variant?: "grid" | "editorial";
  priority?: boolean;
}

export function VehicleCard({ vehicle, variant = "grid", priority = false }: CardProps) {
  const { favorites, toggleFavorite } = useFavorites();
  const { compare, toggleCompare } = useCompare();
  const saved = favorites.includes(vehicle.id);
  const comparing = compare.includes(vehicle.id);
  const editorial = variant === "editorial";

  return (
    <article
      className={`group glass-panel sheen-hover relative overflow-hidden rounded-lg transition-transform duration-500 hover:-translate-y-1 ${
        editorial ? "md:grid md:grid-cols-2" : ""
      }`}
    >
      <Link
        to="/vehicle/$slug"
        params={{ slug: vehicle.slug }}
        className="relative block overflow-hidden"
        aria-label={`View ${vehicle.year} ${vehicle.brand} ${vehicle.model}`}
      >
        <img
          src={vehicle.images[0]}
          alt={`${vehicle.year} ${vehicle.brand} ${vehicle.model} in ${vehicle.exteriorColour}`}
          loading={priority ? "eager" : "lazy"}
          width={1400}
          height={900}
          className={`w-full object-cover transition-transform duration-[900ms] ease-[var(--ease-lux)] group-hover:scale-[1.06] ${
            editorial ? "h-64 md:h-full" : "h-52 sm:h-56"
          }`}
        />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-abyss/85 via-transparent to-transparent" />
        <div className="absolute left-3 top-3 flex flex-wrap gap-2">
          <StatusChip vehicle={vehicle} />
          {vehicle.featured && (
            <span className="rounded-full border border-pearl/50 px-2.5 py-1 text-[0.6rem] tracking-[0.18em] uppercase text-pearl">
              Featured
            </span>
          )}
        </div>
      </Link>

      <div className={`flex flex-col p-5 ${editorial ? "justify-center md:p-8" : ""}`}>
        <p className="eyebrow">{vehicle.brand}</p>
        <h3 className={`font-display mt-1.5 leading-tight ${editorial ? "text-2xl sm:text-3xl" : "text-xl"}`}>
          <Link to="/vehicle/$slug" params={{ slug: vehicle.slug }} className="transition-colors hover:text-pearl">
            {vehicle.model}
          </Link>
        </h3>
        <p className="mt-2 text-lg text-chrome-gradient font-medium">{formatNaira(vehicle.price)}</p>

        <ul className="mt-4 grid grid-cols-2 gap-y-2 text-xs text-muted-foreground">
          <li className="flex items-center gap-1.5">
            <Calendar className="h-3.5 w-3.5" /> {vehicle.year}
          </li>
          <li className="flex items-center gap-1.5">
            <Gauge className="h-3.5 w-3.5" /> {formatMileage(vehicle.mileage)}
          </li>
          <li className="flex items-center gap-1.5">
            <Fuel className="h-3.5 w-3.5" /> {vehicle.fuel}
          </li>
          <li className="flex items-center gap-1.5">
            <MapPin className="h-3.5 w-3.5" /> {vehicle.location}
          </li>
        </ul>

        {editorial && (
          <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
            {vehicle.engine} · {vehicle.power} · {vehicle.transmission} · {vehicle.condition}. Key features include{" "}
            {vehicle.features.slice(0, 3).join(", ").toLowerCase()}.
          </p>
        )}

        <div className="mt-5 flex items-center gap-2">
          <Link
            to="/vehicle/$slug"
            params={{ slug: vehicle.slug }}
            className="flex-1 rounded-full bg-secondary px-4 py-2.5 text-center text-[0.68rem] tracking-[0.18em] uppercase text-secondary-foreground transition-colors hover:bg-accent"
          >
            View Vehicle
          </Link>
          <button
            type="button"
            onClick={() => toggleFavorite(vehicle.id)}
            aria-pressed={saved}
            aria-label={saved ? "Remove from saved cars" : "Save this car"}
            className={`rounded-full border p-2.5 transition-all active:scale-90 ${
              saved ? "border-pearl text-pearl" : "border-border text-muted-foreground hover:text-foreground"
            }`}
          >
            <Heart className={`h-4 w-4 ${saved ? "fill-current" : ""}`} />
          </button>
          <button
            type="button"
            onClick={() => toggleCompare(vehicle.id)}
            aria-pressed={comparing}
            aria-label={comparing ? "Remove from compare" : "Add to compare"}
            className={`rounded-full border p-2.5 transition-all active:scale-90 ${
              comparing ? "border-pearl text-pearl" : "border-border text-muted-foreground hover:text-foreground"
            }`}
          >
            <GitCompareArrows className="h-4 w-4" />
          </button>
          <a
            href={whatsappLink(
              `Hello OST Luxury Cars, I am interested in the ${vehicle.year} ${vehicle.brand} ${vehicle.model} (Ref ${vehicle.id}).`,
            )}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Enquire on WhatsApp"
            className="rounded-full border border-success/40 p-2.5 text-success transition-colors hover:bg-success/15"
          >
            <MessageCircle className="h-4 w-4" />
          </a>
        </div>
      </div>
    </article>
  );
}

export function VehicleCardSkeleton() {
  return (
    <div className="glass-panel animate-pulse overflow-hidden rounded-lg">
      <div className="h-52 bg-secondary/60 sm:h-56" />
      <div className="space-y-3 p-5">
        <div className="h-2.5 w-20 rounded bg-secondary/60" />
        <div className="h-5 w-3/4 rounded bg-secondary/60" />
        <div className="h-4 w-1/3 rounded bg-secondary/60" />
        <div className="h-10 rounded-full bg-secondary/60" />
      </div>
    </div>
  );
}
