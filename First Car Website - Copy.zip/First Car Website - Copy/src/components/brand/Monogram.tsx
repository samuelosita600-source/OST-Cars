interface MonogramProps {
  className?: string;
  title?: string;
}

/** OST monogram — chrome-ringed shield with interlocking letterforms. */
export function Monogram({ className = "h-10 w-10", title = "OST Luxury Cars" }: MonogramProps) {
  return (
    <svg viewBox="0 0 64 64" role="img" aria-label={title} className={className}>
      <defs>
        <linearGradient id="ost-chrome" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="oklch(0.98 0.004 250)" />
          <stop offset="38%" stopColor="oklch(0.7 0.02 250)" />
          <stop offset="55%" stopColor="oklch(0.95 0.006 250)" />
          <stop offset="100%" stopColor="oklch(0.58 0.02 250)" />
        </linearGradient>
        <linearGradient id="ost-pearl" x1="0" y1="1" x2="1" y2="0">
          <stop offset="0%" stopColor="oklch(0.45 0.14 268)" />
          <stop offset="60%" stopColor="oklch(0.78 0.11 245)" />
          <stop offset="100%" stopColor="oklch(0.94 0.03 220)" />
        </linearGradient>
      </defs>
      <path
        d="M32 2.5 58 13v22.5C58 49 46.6 58.4 32 61.5 17.4 58.4 6 49 6 35.5V13L32 2.5Z"
        fill="none"
        stroke="url(#ost-chrome)"
        strokeWidth="1.4"
      />
      <path
        d="M32 7 53.5 15.6v19.6c0 11.2-9.4 19.2-21.5 21.9C19.9 54.4 10.5 46.4 10.5 35.2V15.6L32 7Z"
        fill="oklch(0.13 0.024 264 / 85%)"
      />
      <g fill="none" stroke="url(#ost-pearl)" strokeWidth="2.1" strokeLinecap="round">
        <ellipse cx="24" cy="31" rx="7.4" ry="9.4" />
        <path d="M45.4 23.6c-1.6-1.6-4-2.4-6.2-2-3.6.7-4.6 4.4-2 6.2 1.7 1.2 4.6 1.5 6.2 2.9 2.3 2 1.3 5.8-2.2 6.6-2.3.5-4.9-.3-6.6-2" />
        <path d="M28 45.5h16" />
        <path d="M36 45.5v9.6" />
      </g>
    </svg>
  );
}

export function WordMark({ className = "" }: { className?: string }) {
  return (
    <span className={`font-display leading-none tracking-[0.14em] ${className}`}>
      OST<span className="text-chrome-gradient"> LUXURY</span>
    </span>
  );
}
