import { useState } from "react";
import { toast } from "sonner";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Field, inputClass, textareaClass } from "@/components/site/FormBits";
import { uploadVehicleImage, type VehicleInput } from "@/libs/vehicles-admin";
import {
  AVAILABILITY_OPTIONS,
  BODY_TYPES,
  BRANDS,
  COLOUR_OPTIONS,
  CONDITIONS,
  DRIVETRAINS,
  ENGINE_OPTIONS,
  FUELS,
  IMAGE_ANGLES,
  INSPECTION_OPTIONS,
  INTERIOR_OPTIONS,
  LOCATION_OPTIONS,
  TRANSMISSIONS,
  type Vehicle,
} from "@/data/vehicles";

interface Props {
  vehicle?: Vehicle | null;
  onClose: () => void;
  onSave: (input: VehicleInput) => Promise<void>;
}

/** Full inventory editor — every listing field plus multi-angle image uploads. */
export function VehicleForm({ vehicle, onClose, onSave }: Props) {
  const [images, setImages] = useState<string[]>(vehicle?.images.filter((i) => i.startsWith("http")) ?? []);
  const [uploading, setUploading] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [ref, setRef] = useState(vehicle?.ref ?? "");

  async function handleUpload(angle: string, file: File) {
    setUploading(angle);
    try {
      const url = await uploadVehicleImage(file, ref || "vehicle", angle);
      setImages((prev) => [...prev, url]);
      toast.success(`${angle} photo uploaded`);
    } catch (err) {
      toast.error("Upload failed", { description: err instanceof Error ? err.message : undefined });
    } finally {
      setUploading(null);
    }
  }

  return (
    <div className="fixed inset-0 z-[95] overflow-y-auto">
      <button type="button" aria-label="Close" className="fixed inset-0 bg-abyss/90" onClick={onClose} />
      <form
        className="glass-panel relative mx-auto my-6 w-[min(60rem,94vw)] space-y-5 rounded-lg p-7"
        onSubmit={async (e) => {
          e.preventDefault();
          const f = new FormData(e.currentTarget);
          const num = (k: string) => Number(f.get(k) ?? 0);
          const str = (k: string) => String(f.get(k) ?? "");
          setBusy(true);
          try {
            await onSave({
              ref: str("ref"),
              brand: str("brand"),
              model: str("model"),
              year: num("year"),
              price: num("price"),
              body_type: str("body_type"),
              mileage: num("mileage"),
              transmission: str("transmission"),
              fuel: str("fuel"),
              engine: str("engine"),
              power: str("power"),
              drivetrain: str("drivetrain"),
              exterior_colour: str("exterior_colour"),
              interior_colour: str("interior_colour"),
              location: str("location"),
              condition: str("condition"),
              features: str("features").split(",").map((s) => s.trim()).filter(Boolean),
              availability: str("availability"),
              vin: str("vin"),
              inspection: str("inspection"),
              featured: f.get("featured") === "on",
              seats: num("seats"),
              acceleration: str("acceleration"),
              description: str("description"),
              images,
            });
            onClose();
          } catch (err) {
            toast.error("Could not save vehicle", { description: err instanceof Error ? err.message : undefined });
          } finally {
            setBusy(false);
          }
        }}
      >
        <div className="flex items-start justify-between gap-4">
          <h2 className="font-display text-2xl">{vehicle ? "Edit vehicle" : "Add vehicle"}</h2>
          <button type="button" onClick={onClose} aria-label="Close" className="text-muted-foreground hover:text-foreground">
            <X className="size-5" />
          </button>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <Field label="Reference">
            <input name="ref" required value={ref} onChange={(e) => setRef(e.target.value)} className={inputClass} placeholder="OST-101" />
          </Field>
          <Field label="Brand">
            <select name="brand" defaultValue={vehicle?.brand ?? BRANDS[0]} className={inputClass}>
              {BRANDS.map((b) => <option key={b}>{b}</option>)}
            </select>
          </Field>
          <Field label="Model"><input name="model" required defaultValue={vehicle?.model ?? ""} className={inputClass} placeholder="S 580 4MATIC" /></Field>
          <Field label="Year"><input name="year" required type="number" min={1990} max={2030} defaultValue={vehicle?.year ?? 2023} className={inputClass} /></Field>
          <Field label="Price (₦)"><input name="price" required type="number" min={0} defaultValue={vehicle?.price ?? 0} className={inputClass} /></Field>
          <Field label="Body type">
            <select name="body_type" defaultValue={vehicle?.bodyType ?? BODY_TYPES[0]} className={inputClass}>
              {BODY_TYPES.map((b) => <option key={b}>{b}</option>)}
            </select>
          </Field>
          <Field label="Mileage (km)"><input name="mileage" type="number" min={0} defaultValue={vehicle?.mileage ?? 0} className={inputClass} /></Field>
          <Field label="Transmission">
            <select name="transmission" defaultValue={vehicle?.transmission ?? TRANSMISSIONS[0]} className={inputClass}>
              {TRANSMISSIONS.map((t) => <option key={t}>{t}</option>)}
            </select>
          </Field>
          <Field label="Fuel">
            <select name="fuel" defaultValue={vehicle?.fuel ?? FUELS[0]} className={inputClass}>
              {FUELS.map((t) => <option key={t}>{t}</option>)}
            </select>
          </Field>
          <Field label="Engine">
            <input name="engine" list="engines" defaultValue={vehicle?.engine ?? ""} className={inputClass} placeholder="4.0L V8 Biturbo" />
            <datalist id="engines">{ENGINE_OPTIONS.map((e) => <option key={e} value={e} />)}</datalist>
          </Field>
          <Field label="Power"><input name="power" defaultValue={vehicle?.power ?? ""} className={inputClass} placeholder="496 hp" /></Field>
          <Field label="Drivetrain">
            <select name="drivetrain" defaultValue={vehicle?.drivetrain ?? DRIVETRAINS[0]} className={inputClass}>
              {DRIVETRAINS.map((t) => <option key={t}>{t}</option>)}
            </select>
          </Field>
          <Field label="Exterior colour">
            <input name="exterior_colour" list="colours" defaultValue={vehicle?.exteriorColour ?? ""} className={inputClass} />
            <datalist id="colours">{COLOUR_OPTIONS.map((c) => <option key={c} value={c} />)}</datalist>
          </Field>
          <Field label="Interior colour">
            <input name="interior_colour" list="interiors" defaultValue={vehicle?.interiorColour ?? ""} className={inputClass} />
            <datalist id="interiors">{INTERIOR_OPTIONS.map((c) => <option key={c} value={c} />)}</datalist>
          </Field>
          <Field label="Location">
            <select name="location" defaultValue={vehicle?.location ?? LOCATION_OPTIONS[0]} className={inputClass}>
              {LOCATION_OPTIONS.map((t) => <option key={t}>{t}</option>)}
            </select>
          </Field>
          <Field label="Condition">
            <select name="condition" defaultValue={vehicle?.condition ?? CONDITIONS[0]} className={inputClass}>
              {CONDITIONS.map((t) => <option key={t}>{t}</option>)}
            </select>
          </Field>
          <Field label="Availability">
            <select name="availability" defaultValue={vehicle?.availability ?? AVAILABILITY_OPTIONS[0]} className={inputClass}>
              {AVAILABILITY_OPTIONS.map((t) => <option key={t}>{t}</option>)}
            </select>
          </Field>
          <Field label="Inspection">
            <select name="inspection" defaultValue={vehicle?.inspection ?? INSPECTION_OPTIONS[0]} className={inputClass}>
              {INSPECTION_OPTIONS.map((t) => <option key={t}>{t}</option>)}
            </select>
          </Field>
          <Field label="VIN"><input name="vin" defaultValue={vehicle?.vin ?? ""} className={inputClass} /></Field>
          <Field label="Seats"><input name="seats" type="number" min={2} max={9} defaultValue={vehicle?.seats ?? 5} className={inputClass} /></Field>
          <Field label="0–100 km/h"><input name="acceleration" defaultValue={vehicle?.acceleration ?? ""} className={inputClass} placeholder="4.4s" /></Field>
        </div>

        <Field label="Features (comma separated)">
          <input name="features" defaultValue={vehicle?.features.join(", ") ?? ""} className={inputClass} placeholder="Burmester audio, Panoramic roof" />
        </Field>
        <Field label="Description">
          <textarea name="description" defaultValue={vehicle?.description ?? ""} className={textareaClass} rows={4} />
        </Field>

        <label className="flex items-center gap-3 text-sm">
          <input type="checkbox" name="featured" defaultChecked={vehicle?.featured ?? false} className="size-4 accent-primary" />
          Feature on the homepage
        </label>

        <div>
          <p className="text-[0.6rem] tracking-[0.2em] uppercase text-muted-foreground">Photos</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {IMAGE_ANGLES.map((angle) => (
              <label key={angle} className="cursor-pointer rounded-full border border-border px-4 py-2 text-[0.62rem] tracking-[0.16em] uppercase text-muted-foreground hover:text-foreground">
                {uploading === angle ? "Uploading…" : `Upload ${angle}`}
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) void handleUpload(angle, file);
                    e.target.value = "";
                  }}
                />
              </label>
            ))}
          </div>
          {images.length > 0 && (
            <div className="mt-4 grid grid-cols-3 gap-3 sm:grid-cols-6">
              {images.map((url) => (
                <div key={url} className="relative overflow-hidden rounded-md border border-border">
                  <img src={url} alt="Vehicle photo" className="aspect-[4/3] w-full object-cover" loading="lazy" />
                  <button
                    type="button"
                    aria-label="Remove photo"
                    onClick={() => setImages((prev) => prev.filter((u) => u !== url))}
                    className="absolute right-1 top-1 rounded-full bg-abyss/80 p-1 text-foreground"
                  >
                    <X className="size-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="flex flex-wrap gap-3">
          <Button type="submit" variant="hero" size="lg" disabled={busy}>{busy ? "Saving…" : "Save vehicle"}</Button>
          <Button type="button" variant="chrome" size="lg" onClick={onClose}>Cancel</Button>
        </div>
      </form>
    </div>
  );
}
