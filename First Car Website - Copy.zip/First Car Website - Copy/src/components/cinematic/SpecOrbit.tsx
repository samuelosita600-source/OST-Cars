import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { formatMileage, formatNaira } from "@/lib/format";
import type { Vehicle } from "@/data/vehicles";

/**
 * Bridge from the hero's top view into an engineering profile:
 * a blueprint silhouette orbit that dissolves into a spec panel.
 */
export function SpecOrbit({ vehicle }: { vehicle: Vehicle }) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [p, setP] = useState(0);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const onScroll = () => {
      const rect = el.getBoundingClientRect();
      const total = rect.height - window.innerHeight;
      setP(total > 0 ? Math.min(1, Math.max(0, -rect.top / total)) : 0);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);

  const specs: Array<[string, string]> = [
    ["Model", `${vehicle.brand} ${vehicle.model}`],
    ["Year", String(vehicle.year)],
    ["Price", formatNaira(vehicle.price)],
    ["Engine", vehicle.engine],
    ["Power", vehicle.power],
    ["Transmission", vehicle.transmission],
    ["Fuel", vehicle.fuel],
    ["Mileage", formatMileage(vehicle.mileage)],
    ["Drivetrain", vehicle.drivetrain],
    ["Body type", vehicle.bodyType],
    ["Exterior", vehicle.exteriorColour],
    ["Interior", vehicle.interiorColour],
    ["0–100 km/h", vehicle.acceleration],
    ["Inspection", vehicle.inspection],
  ];

  const blueprint = Math.min(1, p / 0.45);
  const panel = Math.max(0, (p - 0.35) / 0.5);

  return (
    <section ref={ref} aria-label="Featured vehicle engineering profile" className="relative h-[260vh]">
      <div className="sticky top-0 flex h-screen items-center overflow-hidden bg-abyss">
        <div
          className="pointer-events-none absolute inset-0 opacity-[0.07]"
          style={{
            backgroundImage:
              "linear-gradient(oklch(0.86 0.008 250 / 0.5) 1px, transparent 1px), linear-gradient(90deg, oklch(0.86 0.008 250 / 0.5) 1px, transparent 1px)",
            backgroundSize: "64px 64px",
            transform: `translateY(${-p * 40}px)`,
          }}
        />

        <div className="mx-auto grid w-full max-w-7xl gap-10 px-5 sm:px-6 lg:grid-cols-2 lg:items-center">
          {/* blueprint orbit */}
          <div className="relative mx-auto w-full max-w-md" style={{ opacity: 1 - panel * 0.55 }}>
            <svg viewBox="0 0 400 400" className="w-full" role="img" aria-label="Technical top-view blueprint of the featured vehicle">
              <g
                fill="none"
                stroke="oklch(0.86 0.008 250 / 0.55)"
                strokeWidth="1"
                style={{
                  strokeDasharray: 1400,
                  strokeDashoffset: 1400 - blueprint * 1400,
                  transform: `rotate(${p * 12}deg)`,
                  transformOrigin: "200px 200px",
                }}
              >
                <path d="M200 40c26 0 40 16 44 44l6 46c14 4 20 12 20 30v92c0 26-6 48-14 62-10 18-32 26-56 26s-46-8-56-26c-8-14-14-36-14-62v-92c0-18 6-26 20-30l6-46c4-28 18-44 44-44Z" />
                <path d="M160 132h80M156 200h88M162 268h76" />
                <rect x="168" y="150" width="64" height="38" rx="6" />
                <circle cx="200" cy="230" r="16" />
              </g>
              <g
                stroke="oklch(0.62 0.16 255 / 0.7)"
                fill="none"
                strokeWidth="1"
                style={{ opacity: blueprint }}
              >
                <circle cx="200" cy="200" r="150" strokeDasharray="4 10" />
                <circle cx="200" cy="200" r="182" strokeDasharray="2 14" />
              </g>
              {[
                { x: 62, y: 120, label: "AERO" },
                { x: 300, y: 96, label: "CHASSIS" },
                { x: 316, y: 288, label: "DRIVETRAIN" },
                { x: 52, y: 300, label: "CABIN" },
              ].map((d, i) => (
                <g key={d.label} style={{ opacity: Math.min(1, Math.max(0, blueprint * 4 - i)) }}>
                  <circle cx={d.x} cy={d.y} r="3" fill="oklch(0.78 0.11 245)" />
                  <text
                    x={d.x + 8}
                    y={d.y + 4}
                    fill="oklch(0.78 0.11 245)"
                    fontSize="9"
                    letterSpacing="2"
                    fontFamily="var(--font-sans)"
                  >
                    {d.label}
                  </text>
                </g>
              ))}
            </svg>
          </div>

          {/* spec panel */}
          <div
            className="glass-panel rounded-lg p-6 sm:p-9"
            style={{
              opacity: Math.min(1, panel * 1.6),
              transform: `translate3d(0, ${(1 - Math.min(1, panel * 1.6)) * 40}px, 0)`,
            }}
          >
            <p className="eyebrow">Featured — engineering profile</p>
            <h2 className="font-display mt-3 text-3xl leading-tight sm:text-4xl">
              {vehicle.brand} <span className="text-pearl-gradient">{vehicle.model}</span>
            </h2>
            <p className="mt-3 text-sm text-muted-foreground">
              {vehicle.condition} · {vehicle.location} · Ref {vehicle.id}
            </p>

            <dl className="mt-7 grid grid-cols-2 gap-x-6 gap-y-4 sm:grid-cols-3">
              {specs.map(([label, value], i) => {
                const show = Math.min(1, Math.max(0, (panel - 0.08) * 8 - i * 0.5));
                return (
                  <div key={label} style={{ opacity: show, transform: `translateY(${(1 - show) * 10}px)` }}>
                    <dt className="text-[0.6rem] tracking-[0.2em] uppercase text-muted-foreground">{label}</dt>
                    <dd className="mt-1 text-sm text-foreground">{value}</dd>
                  </div>
                );
              })}
            </dl>

            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild variant="hero" size="lg">
                <Link to="/vehicle/$slug" params={{ slug: vehicle.slug }}>
                  View this vehicle
                </Link>
              </Button>
              <Button asChild variant="chrome" size="lg">
                <Link to="/inventory">Browse all 100</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
