import { useEffect, useRef, useState } from "react";
import { ChevronDown, Volume2, VolumeX } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import carVideo from "@/assets/ost-car-orbit.mp4";
import carPoster from "@/assets/ost-car-poster.jpg";

const CAPTIONS = [
  { at: 0, title: "Luxury, Curated.", sub: "Every vehicle chosen, inspected, and presented with intent." },
  { at: 0.3, title: "Performance, Defined.", sub: "Engineering you feel before you hear it." },
  { at: 0.6, title: "Presence That Stays.", sub: "Arrive once. Be remembered." },
  { at: 0.85, title: "Choose Ur Car Wisely.", sub: "OST Luxury Cars — Nigeria's curated automotive house." },
];

/**
 * Scroll-scrubbed hero. The video is pinned full-viewport and its currentTime is
 * driven directly by scroll progress through a tall spacer, so scrolling up
 * reverses the camera orbit exactly and stopping freezes the frame.
 */
export function ScrollVideoHero() {
  const sectionRef = useRef<HTMLDivElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const targetTime = useRef(0);
  const rafRef = useRef<number | null>(null);
  const [progress, setProgress] = useState(0);
  const [muted, setMuted] = useState(true);
  const [ready, setReady] = useState(false);
  const [reduced, setReduced] = useState(false);

  useEffect(() => {
    setReduced(window.matchMedia("(prefers-reduced-motion: reduce)").matches);
  }, []);

  useEffect(() => {
    const section = sectionRef.current;
    const video = videoRef.current;
    if (!section || !video) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    let latest = 0;

    const apply = () => {
      rafRef.current = null;
      const duration = video.duration;
      if (!Number.isFinite(duration) || duration <= 0) return;
      const t = Math.min(duration - 0.03, Math.max(0, latest * duration));
      targetTime.current = t;
      if (Math.abs(video.currentTime - t) > 0.012 && video.readyState >= 1) {
        try {
          video.currentTime = t;
        } catch {
          /* seek not ready yet */
        }
      }
    };

    const onScroll = () => {
      const rect = section.getBoundingClientRect();
      const total = section.offsetHeight - window.innerHeight;
      const p = total > 0 ? Math.min(1, Math.max(0, -rect.top / total)) : 0;
      latest = p;
      setProgress(p);
      if (rafRef.current === null) rafRef.current = requestAnimationFrame(apply);
    };

    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  const active = CAPTIONS.reduce((acc, c, i) => (progress >= c.at ? i : acc), 0);
  const caption = CAPTIONS[active] ?? CAPTIONS[0]!;

  return (
    <section
      ref={sectionRef}
      aria-label="OST Luxury Cars cinematic introduction"
      className="relative h-[420vh] md:h-[500vh]"
    >
      <div className="sticky top-0 h-screen overflow-hidden bg-abyss">
        <video
          ref={videoRef}
          src={carVideo}
          poster={carPoster}
          muted={muted}
          playsInline
          preload="auto"
          aria-label="Camera orbiting a stationary luxury car, from the front around to a top view"
          onLoadedMetadata={() => setReady(true)}
          className="absolute inset-0 h-full w-full object-cover opacity-95"
          style={{ transform: `scale(${1.08 - progress * 0.06})`, transition: "transform 120ms linear" }}
        />

        {/* cinematic vignette + pearl light */}
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_35%,oklch(0.09_0.015_265/0.85)_100%)]" />
        <div
          className="pointer-events-none absolute inset-x-0 bottom-0 h-1/2"
          style={{
            background: "linear-gradient(to top, oklch(0.09 0.015 265) 5%, transparent 100%)",
          }}
        />
        <div
          className="pointer-events-none absolute -left-1/4 top-1/3 h-[45vh] w-[45vh] rounded-full opacity-25 blur-[120px]"
          style={{ backgroundImage: "var(--gradient-pearl)", transform: `translateX(${progress * 60}vw)` }}
        />

        <div className="relative z-10 flex h-full flex-col justify-end pb-24 sm:justify-center sm:pb-0">
          <div className="mx-auto w-full max-w-7xl px-5 sm:px-6">
            <p className="eyebrow mb-4">OST Luxury Cars — Kugbo, Abuja</p>
            <div className="min-h-[9.5rem] sm:min-h-[12rem]">
              {CAPTIONS.map((c, i) => (
                <div
                  key={c.title}
                  aria-hidden={i !== active}
                  className={`transition-all duration-700 ${
                    i === active ? "opacity-100" : "pointer-events-none absolute opacity-0"
                  }`}
                  style={i === active ? undefined : { transform: "translateY(12px)" }}
                >
                  {i === active && (
                    <>
                      <h1 className="font-display max-w-3xl text-4xl leading-[1.05] sm:text-6xl lg:text-7xl">
                        <span className="text-chrome-gradient">{caption.title}</span>
                      </h1>
                      <p className="mt-5 max-w-lg text-sm leading-relaxed tracking-wide text-muted-foreground sm:text-base">
                        {caption.sub}
                      </p>
                    </>
                  )}
                </div>
              ))}
            </div>

            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Button asChild variant="hero" size="xl">
                <Link to="/inventory">Explore Collection</Link>
              </Button>
              <Button asChild variant="chrome" size="xl">
                <Link to="/test-drive">Book a Test Drive</Link>
              </Button>
            </div>
          </div>
        </div>

        {/* progress rail */}
        <div className="absolute right-5 top-1/2 z-10 hidden h-40 w-px -translate-y-1/2 bg-border lg:block">
          <div
            className="w-px origin-top"
            style={{
              height: `${progress * 100}%`,
              backgroundImage: "var(--gradient-chrome)",
            }}
          />
        </div>

        <div className="absolute bottom-5 left-0 right-0 z-10 flex items-center justify-between px-5 sm:px-6">
          <div
            className={`flex items-center gap-2 text-[0.6rem] tracking-[0.3em] text-muted-foreground transition-opacity duration-500 ${
              progress > 0.04 ? "opacity-0" : "opacity-100"
            }`}
          >
            <ChevronDown className="h-4 w-4 animate-bounce" />
            SCROLL TO ORBIT
          </div>
          <button
            type="button"
            onClick={() => setMuted((m) => !m)}
            aria-label={muted ? "Enable ambient studio sound" : "Mute ambient studio sound"}
            className="flex items-center gap-2 rounded-full border border-border px-3.5 py-2 text-[0.6rem] tracking-[0.22em] uppercase text-muted-foreground backdrop-blur-md transition-colors hover:text-foreground"
          >
            {muted ? <VolumeX className="h-3.5 w-3.5" /> : <Volume2 className="h-3.5 w-3.5" />}
            {muted ? "Sound off" : "Sound on"}
          </button>
        </div>

        {(reduced || !ready) && (
          <p className="sr-only">
            Cinematic sequence: the camera moves from the front of a stationary luxury car, around the side and rear, to
            a top view. Reduced-motion viewers see the same narrative as still frames and text.
          </p>
        )}
      </div>
    </section>
  );
}
