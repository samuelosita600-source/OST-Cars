import { useEffect, useState } from "react";
import { Monogram } from "@/components/brand/Monogram";

/**
 * Black-screen opening moment. Fades away on its own, on scroll, or on skip.
 * Respects reduced motion by collapsing to a very short fade.
 */
export function CinematicIntro() {
  const [progress, setProgress] = useState(0);
  const [dismissed, setDismissed] = useState(false);
  const [hidden, setHidden] = useState(false);

  useEffect(() => {
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduced) {
      setProgress(100);
      const t = window.setTimeout(() => setDismissed(true), 250);
      return () => window.clearTimeout(t);
    }
    let raf = 0;
    const start = performance.now();
    const duration = 2200;
    const tick = (now: number) => {
      const p = Math.min(100, ((now - start) / duration) * 100);
      setProgress(p);
      if (p < 100) raf = requestAnimationFrame(tick);
      else window.setTimeout(() => setDismissed(true), 700);
    };
    raf = requestAnimationFrame(tick);
    const onScroll = () => setDismissed(true);
    window.addEventListener("scroll", onScroll, { passive: true, once: true });
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("scroll", onScroll);
    };
  }, []);

  useEffect(() => {
    if (!dismissed) return;
    const t = window.setTimeout(() => setHidden(true), 900);
    return () => window.clearTimeout(t);
  }, [dismissed]);

  if (hidden) return null;

  return (
    <div
      aria-hidden={dismissed}
      className={`fixed inset-0 z-[80] grid place-items-center bg-abyss transition-opacity duration-[900ms] ${
        dismissed ? "pointer-events-none opacity-0" : "opacity-100"
      }`}
    >
      <div className="relative flex w-full max-w-md flex-col items-center px-8 text-center">
        <div
          className="absolute -top-24 h-64 w-64 rounded-full opacity-40 blur-3xl"
          style={{ backgroundImage: "var(--gradient-pearl)" }}
        />
        <Monogram className="relative h-20 w-20 opacity-90" />
        <p className="eyebrow relative mt-8">OST Luxury Cars</p>
        <h1 className="font-display relative mt-3 text-3xl">
          <span className="text-pearl-gradient">Choose Ur Car Wisely</span>
        </h1>
        <div className="relative mt-10 h-px w-full overflow-hidden bg-border">
          <div
            className="h-full transition-[width] duration-200 ease-out"
            style={{ width: `${progress}%`, backgroundImage: "var(--gradient-chrome)" }}
          />
        </div>
        <p className="relative mt-4 text-[0.65rem] tracking-[0.3em] text-muted-foreground">
          {progress < 100 ? "PREPARING THE STUDIO" : "READY"}
        </p>
        <button
          type="button"
          onClick={() => setDismissed(true)}
          className="relative mt-10 rounded-full border border-border px-6 py-2.5 text-[0.65rem] tracking-[0.25em] uppercase text-muted-foreground transition-colors hover:border-pearl hover:text-foreground"
        >
          Enter
        </button>
      </div>
    </div>
  );
}
