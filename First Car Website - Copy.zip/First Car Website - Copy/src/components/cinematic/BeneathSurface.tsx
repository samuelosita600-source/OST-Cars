import { useEffect, useRef, useState } from "react";
import { Volume2, VolumeX } from "lucide-react";
import detailImg from "@/assets/detail.jpg";
import interiorImg from "@/assets/interior.jpg";
import engineImg from "@/assets/engine.jpg";

const CHAPTERS = [
  {
    key: "exterior",
    eyebrow: "Chapter I — Bodywork",
    title: "Light is the first material.",
    copy: "Pearl-blue lacquer, chrome shoulder lines and hand-finished panels. Every surface is inspected under studio light before it reaches you.",
    image: detailImg,
    points: ["Multi-stage paint inspection", "Panel-gap verification", "Ceramic-ready finish"],
  },
  {
    key: "cabin",
    eyebrow: "Chapter II — Cabin",
    title: "Silence, engineered.",
    copy: "Quilted Nappa leather, ambient lighting tuned to the hour, and a cockpit that answers before you ask. Comfort here is measured in decibels removed.",
    image: interiorImg,
    points: ["Massage & ventilated seating", "64-colour ambient lighting", "Acoustic laminated glass"],
  },
  {
    key: "engine",
    eyebrow: "Chapter III — Engineering",
    title: "Composure at full commitment.",
    copy: "Forced-induction power delivered through adaptive damping and a chassis calibrated for Nigerian roads. Numbers you can feel, not just read.",
    image: engineImg,
    points: ["Torque delivered from 1,800 rpm", "Adaptive air suspension", "Full service history verified"],
  },
] as const;

export function BeneathSurface() {
  const ref = useRef<HTMLDivElement | null>(null);
  const [p, setP] = useState(0);
  const [sound, setSound] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const onScroll = () => {
      const rect = el.getBoundingClientRect();
      const total = rect.height - window.innerHeight;
      setP(total > 0 ? Math.min(1, Math.max(0, -rect.top / total)) : 0);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);

  const index = Math.min(CHAPTERS.length - 1, Math.floor(p * CHAPTERS.length * 0.999));
  const local = p * CHAPTERS.length - index;
  const chapter = CHAPTERS[index]!;

  return (
    <section ref={ref} aria-label="Discover beneath the surface" className="relative h-[300vh]">
      <div className="sticky top-0 h-screen overflow-hidden bg-abyss">
        {CHAPTERS.map((c, i) => (
          <img
            key={c.key}
            src={c.image}
            alt={c.title}
            loading="lazy"
            width={1600}
            height={1000}
            className="absolute inset-0 h-full w-full object-cover transition-opacity duration-700"
            style={{
              opacity: i === index ? 0.55 : 0,
              transform: `scale(${1.06 + local * 0.05})`,
              clipPath: i === index ? `inset(0% 0% ${Math.max(0, 8 - local * 8)}% 0%)` : undefined,
            }}
          />
        ))}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_30%_50%,transparent_10%,oklch(0.09_0.015_265/0.92)_85%)]" />

        <div className="relative flex h-full items-center">
          <div className="mx-auto grid w-full max-w-7xl gap-10 px-5 sm:px-6 lg:grid-cols-2">
            <div>
              <p className="eyebrow">Discover Beneath the Surface</p>
              <div className="mt-6 flex gap-2" aria-hidden="true">
                {CHAPTERS.map((c, i) => (
                  <span
                    key={c.key}
                    className="h-px w-14 overflow-hidden bg-border"
                  >
                    <span
                      className="block h-px"
                      style={{
                        width: i < index ? "100%" : i === index ? `${local * 100}%` : "0%",
                        backgroundImage: "var(--gradient-chrome)",
                      }}
                    />
                  </span>
                ))}
              </div>
              <p className="mt-8 text-[0.65rem] tracking-[0.3em] text-pearl">{chapter.eyebrow}</p>
              <h2 className="font-display mt-4 max-w-xl text-3xl leading-[1.1] sm:text-5xl">
                <span className="text-chrome-gradient">{chapter.title}</span>
              </h2>
              <p className="mt-5 max-w-md text-sm leading-relaxed text-muted-foreground sm:text-base">
                {chapter.copy}
              </p>
              <ul className="mt-7 space-y-2.5">
                {chapter.points.map((pt, i) => (
                  <li
                    key={pt}
                    className="flex items-center gap-3 text-sm text-foreground/90 transition-all duration-500"
                    style={{
                      opacity: Math.min(1, Math.max(0, local * 4 - i * 0.6)),
                      transform: `translateX(${(1 - Math.min(1, local * 4 - i * 0.6)) * 14}px)`,
                    }}
                  >
                    <span className="h-1 w-6 rounded-full" style={{ backgroundImage: "var(--gradient-pearl)" }} />
                    {pt}
                  </li>
                ))}
              </ul>
              {index === 2 && (
                <button
                  type="button"
                  onClick={() => setSound((s) => !s)}
                  className="mt-8 inline-flex items-center gap-2 rounded-full border border-border px-4 py-2.5 text-[0.62rem] tracking-[0.22em] uppercase text-muted-foreground transition-colors hover:text-foreground"
                >
                  {sound ? <Volume2 className="h-3.5 w-3.5" /> : <VolumeX className="h-3.5 w-3.5" />}
                  {sound ? "Exhaust note on" : "Hear the exhaust note"}
                </button>
              )}
            </div>

            {/* technical read-out */}
            <div className="hidden lg:flex lg:items-center lg:justify-end">
              <div className="glass-panel w-full max-w-sm rounded-lg p-7">
                <p className="eyebrow">Live read-out</p>
                {[
                  { label: "Power", value: Math.round(160 + p * 497), unit: "hp", max: 657 },
                  { label: "Torque", value: Math.round(220 + p * 630), unit: "Nm", max: 850 },
                  { label: "Cabin noise", value: Math.round(64 - p * 26), unit: "dB", max: 70 },
                ].map((m) => (
                  <div key={m.label} className="mt-6">
                    <div className="flex items-baseline justify-between">
                      <span className="text-[0.62rem] tracking-[0.22em] uppercase text-muted-foreground">
                        {m.label}
                      </span>
                      <span className="font-display text-2xl text-chrome-gradient">
                        {m.value.toLocaleString("en-NG")}
                        <span className="ml-1 text-xs">{m.unit}</span>
                      </span>
                    </div>
                    <div className="mt-2 h-px w-full bg-border">
                      <div
                        className="h-px"
                        style={{
                          width: `${(m.value / m.max) * 100}%`,
                          backgroundImage: "var(--gradient-pearl)",
                        }}
                      />
                    </div>
                  </div>
                ))}
                <p className="mt-7 text-[0.68rem] leading-relaxed text-muted-foreground">
                  Indicative figures for the featured vehicle class. Exact specifications are confirmed per vehicle
                  during inspection.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
