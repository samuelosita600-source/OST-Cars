export interface Post {
  slug: string;
  title: string;
  category: string;
  excerpt: string;
  date: string;
  readTime: string;
  body: string[];
}

export const POSTS: Post[] = [
  {
    slug: "importing-a-luxury-car-into-nigeria",
    title: "Importing a luxury car into Nigeria: what to budget for",
    category: "Ownership guide",
    excerpt:
      "Duty, clearing, terminal charges and logistics all change the true landed cost. Here is how we model it before you commit.",
    date: "12 Aug 2026",
    readTime: "6 min read",
    body: [
      "The sticker price abroad is rarely the final number. Landed cost includes freight, import duty, levies, terminal handling, clearing agent fees and inland delivery.",
      "We build a landed-cost sheet before any sourcing commitment so you see the full Naira figure up front, including a contingency for FX movement between order and clearance.",
      "Documentation matters as much as money. Ensure the bill of lading, invoice and certificate of registration all match the chassis number exactly — mismatches cause the most costly delays.",
    ],
  },
  {
    slug: "foreign-used-vs-brand-new",
    title: "Foreign used vs brand new: the honest comparison",
    category: "Buying advice",
    excerpt:
      "Depreciation, warranty, parts availability and resale demand in Nigeria — a practical framework instead of opinions.",
    date: "02 Aug 2026",
    readTime: "5 min read",
    body: [
      "Brand new buys you warranty and certainty. Foreign used buys you value, provided the inspection is genuinely independent.",
      "For high-mileage Lagos commuting we look closely at suspension wear, cooling system health and transmission service history.",
      "Resale demand in Nigeria still favours specific colours and configurations. A well-specified white or black SUV typically holds value better than an unusual colour.",
    ],
  },
  {
    slug: "maintaining-an-suv-on-nigerian-roads",
    title: "Maintaining a luxury SUV on Nigerian roads",
    category: "Ownership guide",
    excerpt:
      "Suspension, tyres, filters and air-conditioning take the most punishment. A realistic service rhythm for local conditions.",
    date: "24 Jul 2026",
    readTime: "4 min read",
    body: [
      "Shorten oil and filter intervals relative to the manual — dust and stop-start traffic are harder on the engine than highway kilometres.",
      "Budget for suspension components earlier than the schedule suggests, especially bushings and air-suspension compressors.",
      "Keep a trusted diagnostic partner. Early fault codes are far cheaper than the failures they precede.",
    ],
  },
  {
    slug: "armoured-vehicles-what-to-know",
    title: "Armoured vehicles: what buyers should verify",
    category: "Market notes",
    excerpt: "Protection levels, certification, weight implications and how armouring affects everyday usability.",
    date: "15 Jul 2026",
    readTime: "7 min read",
    body: [
      "Ask for the armouring specification and the certifying body. Protection level claims without documentation are not verifiable.",
      "Added mass changes braking distance, tyre load ratings and suspension life. Reputable conversions upgrade all three.",
      "Confirm whether glass, pillars and floor are all treated — partial conversions are common and materially different.",
    ],
  },
];

export const SERVICES = [
  {
    title: "Vehicle sourcing",
    copy: "Tell us the exact make, model, year and specification. We search local and international channels and report back with verified options.",
  },
  {
    title: "Independent inspection",
    copy: "Multi-point mechanical, electrical, diagnostic and cosmetic inspection with a written summary before you commit.",
  },
  {
    title: "Import support",
    copy: "Landed-cost modelling, shipping coordination and clearing support so the final Naira figure is clear from the start.",
  },
  {
    title: "Detailing & reconditioning",
    copy: "Paint correction, interior restoration and protective coatings carried out before handover.",
  },
  {
    title: "Concierge purchase",
    copy: "One dedicated contact managing viewing, negotiation, paperwork and delivery scheduling.",
  },
  {
    title: "Trade-in appraisal",
    copy: "Structured valuation of your current vehicle applied directly against your next purchase.",
  },
  {
    title: "Financing assistance",
    copy: "Guidance on preparing a finance application and connecting with lenders. We do not guarantee approval or represent any lender.",
  },
  {
    title: "Documentation guidance",
    copy: "Support with registration, transfer of ownership and record-keeping requirements.",
  },
  {
    title: "After-sales support",
    copy: "Service scheduling, parts sourcing guidance and ongoing ownership support after handover.",
  },
];
