import sedanImg from "@/assets/car-sedan.jpg";
import suvImg from "@/assets/car-suv.jpg";
import performanceImg from "@/assets/car-performance.jpg";
import interiorImg from "@/assets/interior.jpg";
import engineImg from "@/assets/engine.jpg";
import detailImg from "@/assets/detail.jpg";

/**
 * Types, taxonomy and image fallbacks.
 * Vehicle records themselves live in the database (public.vehicles) and are
 * read through src/lib/vehicles.functions.ts.
 */

export type BodyType =
  | "Luxury Sedan"
  | "SUV"
  | "Performance"
  | "Coupe"
  | "Convertible"
  | "Executive"
  | "Electric/Hybrid"
  | "Armoured";

export type Availability = "Available" | "Reserved" | "Sold" | "Incoming";

export interface Vehicle {
  id: string;
  ref: string;
  slug: string;
  brand: string;
  model: string;
  year: number;
  price: number;
  bodyType: BodyType;
  mileage: number;
  transmission: string;
  fuel: string;
  engine: string;
  power: string;
  drivetrain: string;
  exteriorColour: string;
  interiorColour: string;
  images: string[];
  location: string;
  condition: string;
  features: string[];
  availability: Availability;
  vin: string;
  inspection: string;
  featured: boolean;
  dateAdded: string;
  seats: number;
  acceleration: string;
  description: string | null;
}

const IMAGE_POOL: Record<string, string[]> = {
  SUV: [suvImg, interiorImg, engineImg, detailImg],
  Performance: [performanceImg, interiorImg, engineImg, detailImg],
  Coupe: [performanceImg, detailImg, interiorImg, engineImg],
  Convertible: [performanceImg, interiorImg, detailImg, engineImg],
  default: [sedanImg, interiorImg, engineImg, detailImg],
};

/** Studio imagery used when a listing has no uploaded photos yet. */
export function fallbackImages(bodyType: string): string[] {
  return IMAGE_POOL[bodyType] ?? (IMAGE_POOL["default"] as string[]);
}

export const BODY_TYPES: BodyType[] = [
  "Luxury Sedan",
  "SUV",
  "Performance",
  "Coupe",
  "Convertible",
  "Executive",
  "Electric/Hybrid",
  "Armoured",
];

export const BRANDS = [
  "Audi",
  "Bentley",
  "BMW",
  "Ferrari",
  "Genesis",
  "Infiniti",
  "Jaguar",
  "Lamborghini",
  "Land Rover",
  "Lexus",
  "Maserati",
  "Mercedes-Benz",
  "Porsche",
  "Range Rover",
  "Rolls-Royce",
  "Tesla",
  "Toyota",
  "Volkswagen",
  "Volvo",
];

export const FUELS = ["Petrol", "Diesel", "Hybrid", "Electric"];
export const TRANSMISSIONS = ["Automatic", "Manual", "Dual-Clutch", "Single-Speed"];
export const DRIVETRAINS = ["AWD", "RWD", "FWD", "4WD"];
export const CONDITIONS = ["Brand New", "Foreign Used", "Nigerian Used"];
export const INSPECTION_OPTIONS = ["Inspected", "Pending Inspection"];
export const AVAILABILITY_OPTIONS: Availability[] = ["Available", "Reserved", "Sold", "Incoming"];

export const COLOUR_OPTIONS = [
  "Obsidian Black",
  "Diamond White",
  "Nardo Grey",
  "Selenite Grey",
  "Cashmere Silver",
  "Midnight Blue",
  "British Racing Green",
  "Bordeaux Red",
  "Pearl White",
  "Graphite Metallic",
];

export const INTERIOR_OPTIONS = [
  "Black Nappa Leather",
  "Macchiato Beige",
  "Cognac Brown",
  "Pearl White Leather",
  "Charcoal Alcantara",
  "Ivory White",
  "Bordeaux Red",
];

export const LOCATION_OPTIONS = ["Abuja", "Lagos", "Port Harcourt", "Kano", "Ibadan", "Enugu"];

export const IMAGE_ANGLES = ["Front", "Rear", "Side", "Interior", "Engine", "Detail"];

export const ENGINE_OPTIONS = [
  "3.0L Inline-6 Turbo",
  "4.0L V8 Biturbo",
  "2.0L Turbo",
  "3.0L V6 Turbo",
  "5.0L V8",
  "6.75L V12",
  "6.5L V12",
  "3.9L V8 Twin-Turbo",
  "Dual Motor Electric",
  "2.0L Turbo MHEV",
  "3.5L V6 Turbo",
  "4.4L V8 Twin-Turbo",
];

export const PRICE_MIN = 20_000_000;
export const PRICE_MAX = 900_000_000;

export const CATEGORIES: Array<{ label: BodyType; blurb: string; image: string }> = [
  { label: "Luxury Sedan", blurb: "Composed, quiet, effortlessly executive.", image: sedanImg },
  { label: "SUV", blurb: "Commanding presence for Nigerian roads.", image: suvImg },
  { label: "Performance", blurb: "Engineering with intent.", image: performanceImg },
  { label: "Coupe", blurb: "Two doors. One statement.", image: performanceImg },
  { label: "Convertible", blurb: "Open-air luxury, on demand.", image: detailImg },
  { label: "Executive", blurb: "Rear-seat sanctuaries.", image: sedanImg },
  { label: "Electric/Hybrid", blurb: "The quiet future.", image: suvImg },
  { label: "Armoured", blurb: "Discreet protection, uncompromised comfort.", image: sedanImg },
];

export function getVehiclesByIds(ids: string[], all: Vehicle[]): Vehicle[] {
  return ids.map((id) => all.find((v) => v.id === id)).filter((v): v is Vehicle => Boolean(v));
}
