import { createFileRoute } from "@tanstack/react-router";
import { PageHero, Section } from "@/components/site/Section";
import { Button } from "@/components/ui/button";
import { Field, inputClass, textareaClass } from "@/components/site/FormBits";
import { useState } from "react";
import { toast } from "sonner";
import { formatNaira, monthlyPayment, whatsappLink } from "@/lib/format";

export const Route = createFileRoute("/financing")({
  head: () => ({
    meta: [
      { title: "Car Financing in Nigeria — Monthly Estimator | OST Luxury Cars" },
      { name: "description", content: "Estimate monthly payments in Naira on a luxury vehicle. Adjust deposit, duration and indicative rate. Estimates only, subject to lender approval." },
      { property: "og:title", content: "Car Financing in Nigeria — Monthly Estimator | OST Luxury Cars" },
      { property: "og:description", content: "Estimate monthly payments in Naira on a luxury vehicle. Adjust deposit, duration and indicative rate. Estimates only, subject to lender approval." },
    ],
  }),
  component: FinancingPage,
});

function FinancingPage() {
  const [price, setPrice] = useState(150000000);
  const [deposit, setDeposit] = useState(30);
  const [months, setMonths] = useState(48);
  const [rate, setRate] = useState(24);
  const principal = price * (1 - deposit / 100);
  const monthly = monthlyPayment(principal, rate, months);

  return (
    <>
      <PageHero eyebrow="Financing" title="Understand the monthly number first."
        lead="Model your deposit, duration and an indicative rate before you speak to any lender. All figures in Naira." />
      <Section>
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="glass-panel space-y-6 rounded-lg p-7">
            <Field label={`Vehicle price — ${formatNaira(price)}`}>
              <input type="range" min={20000000} max={900000000} step={5000000} value={price}
                onChange={(e) => setPrice(Number(e.target.value))} className="w-full" />
            </Field>
            <Field label={`Deposit — ${deposit}% (${formatNaira(price * deposit / 100)})`}>
              <input type="range" min={10} max={80} step={5} value={deposit}
                onChange={(e) => setDeposit(Number(e.target.value))} className="w-full" />
            </Field>
            <Field label={`Duration — ${months} months`}>
              <input type="range" min={12} max={72} step={6} value={months}
                onChange={(e) => setMonths(Number(e.target.value))} className="w-full" />
            </Field>
            <Field label={`Indicative annual rate — ${rate}%`} hint="Rates vary by lender, tenure and profile.">
              <input type="range" min={8} max={40} step={1} value={rate}
                onChange={(e) => setRate(Number(e.target.value))} className="w-full" />
            </Field>
          </div>
          <div className="glass-panel flex flex-col justify-center rounded-lg p-7">
            <p className="eyebrow">Estimated monthly payment</p>
            <p className="font-display mt-4 text-4xl sm:text-5xl"><span className="text-pearl-gradient">{formatNaira(monthly)}</span></p>
            <dl className="mt-8 space-y-3 text-sm">
              <div className="flex justify-between border-t border-border pt-3"><dt className="text-muted-foreground">Amount financed</dt><dd>{formatNaira(principal)}</dd></div>
              <div className="flex justify-between border-t border-border pt-3"><dt className="text-muted-foreground">Total payable (est.)</dt><dd>{formatNaira(monthly * months)}</dd></div>
              <div className="flex justify-between border-t border-border pt-3"><dt className="text-muted-foreground">Deposit</dt><dd>{formatNaira(price * deposit / 100)}</dd></div>
            </dl>
            <p className="mt-6 text-xs leading-relaxed text-muted-foreground">
              These are estimates for planning only. OST Luxury Cars is not a lender and does not guarantee approval,
              rates or terms. Final figures are set by the lender you choose.
            </p>
          </div>
        </div>

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {[
            ["01", "Share your target vehicle", "Tell us the vehicle and budget you have in mind."],
            ["02", "Prepare documentation", "We guide you on the documents lenders typically request."],
            ["03", "Lender assessment", "You submit to your preferred lender for assessment."],
            ["04", "Completion & handover", "On approval we finalise inspection, payment and delivery."],
          ].map(([n, t, c]) => (
            <div key={n} className="glass-panel rounded-lg p-6">
              <p className="font-display text-2xl text-pearl">{n}</p>
              <h3 className="font-display mt-3 text-lg">{t}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{c}</p>
            </div>
          ))}
        </div>

        <form className="glass-panel mt-14 grid gap-4 rounded-lg p-7 sm:grid-cols-2"
          onSubmit={(e) => { e.preventDefault(); toast.success("Finance enquiry received", { description: "A concierge will follow up shortly." }); }}>
          <h2 className="font-display text-2xl sm:col-span-2">Finance enquiry</h2>
          <Field label="Full name"><input required className={inputClass} placeholder="Your name" /></Field>
          <Field label="Phone / WhatsApp"><input required type="tel" className={inputClass} placeholder="080 0000 0000" /></Field>
          <Field label="Email"><input type="email" className={inputClass} placeholder="you@example.com" /></Field>
          <Field label="Vehicle of interest"><input className={inputClass} placeholder="e.g. Range Rover Sport" /></Field>
          <div className="sm:col-span-2">
            <Field label="Anything else we should know?"><textarea className={textareaClass} /></Field>
          </div>
          <div className="flex flex-wrap gap-3 sm:col-span-2">
            <Button type="submit" variant="hero" size="xl">Submit enquiry</Button>
            <Button asChild variant="whatsapp" size="xl">
              <a href={whatsappLink("Hello OST Luxury Cars, I would like to discuss financing options.")} target="_blank" rel="noopener noreferrer">Speak to a concierge</a>
            </Button>
          </div>
        </form>
      </Section>
    </>
  );
}
