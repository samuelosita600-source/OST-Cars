import { createFileRoute } from "@tanstack/react-router";
import { PageHero, Section } from "@/components/site/Section";
import { Button } from "@/components/ui/button";
import { Field, inputClass, textareaClass } from "@/components/site/FormBits";
import { useState } from "react";
import { toast } from "sonner";
import { SERVICES } from "@/data/content";
import { whatsappLink } from "@/lib/format";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Dealership Services — Sourcing, Inspection, Import | OST Luxury Cars" },
      { name: "description", content: "Vehicle sourcing, independent inspection, import support, detailing, concierge purchase, trade-in appraisal and after-sales support in Nigeria." },
      { property: "og:title", content: "Dealership Services — Sourcing, Inspection, Import | OST Luxury Cars" },
      { property: "og:description", content: "Vehicle sourcing, independent inspection, import support, detailing, concierge purchase, trade-in appraisal and after-sales support in Nigeria." },
    ],
  }),
  component: ServicesPage,
});

function ServicesPage() {
  return (
    <>
      <PageHero eyebrow="Services" title="Everything around the vehicle." lead="Configurable dealership services covering sourcing through to after-sales support." />
      <Section>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((s, i) => (
            <div key={s.title} className="reveal glass-panel rounded-lg p-7" style={{ transitionDelay: `${i * 50}ms` }}>
              <h2 className="font-display text-xl">{s.title}</h2>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{s.copy}</p>
            </div>
          ))}
        </div>
        <div className="mt-12 flex flex-wrap gap-3">
          <Button asChild variant="hero" size="xl">
            <a href={whatsappLink("Hello OST Luxury Cars, I would like to enquire about your services.")} target="_blank" rel="noopener noreferrer">Discuss your requirement</a>
          </Button>
        </div>
      </Section>
    </>
  );
}
