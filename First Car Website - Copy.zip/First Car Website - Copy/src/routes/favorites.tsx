import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHero } from "@/components/site/Section";
import { Button } from "@/components/ui/button";
import { VehicleCard } from "@/components/vehicles/VehicleCard";
import { getVehiclesByIds } from "@/data/vehicles";
import { listVehicles } from "@/libs/vehicles.functions";
import { useFavorites } from "@/libs/store";

export const Route = createFileRoute("/favorites")({
  loader: () => listVehicles(),
  head: () => ({
    meta: [
      { title: "Saved Cars | OST Luxury Cars" },
      { name: "description", content: "Your shortlist of saved luxury vehicles at OST Luxury Cars, ready to compare, reserve or enquire about." },
      { property: "og:title", content: "Saved Cars | OST Luxury Cars" },
      { property: "og:description", content: "Your personal shortlist of curated luxury vehicles." },
    ],
  }),
  component: FavoritesPage,
});

function FavoritesPage() {
  const all = Route.useLoaderData();
  const { favorites, clearFavorites, persisted } = useFavorites();
  const list = getVehiclesByIds(favorites, all);

  return (
    <>
      <PageHero eyebrow="Saved" title="Your shortlist." lead={persisted ? "Saved to your account — available on every device you sign in from." : "Sign in to keep your shortlist across devices."} />
      <div className="mx-auto max-w-7xl px-5 py-12 sm:px-6">
        {list.length === 0 ? (
          <div className="glass-panel rounded-lg p-12 text-center">
            <h2 className="font-display text-2xl">Nothing saved yet</h2>
            <p className="mt-3 text-sm text-muted-foreground">Tap the heart on any vehicle to keep it here.</p>
            <Button asChild variant="hero" size="lg" className="mt-6"><Link to="/inventory">Browse the collection</Link></Button>
          </div>
        ) : (
          <>
            <div className="mb-6 flex items-center justify-between">
              <p className="text-sm text-muted-foreground">{list.length} saved</p>
              <Button variant="chrome" size="lg" onClick={clearFavorites}>Clear all</Button>
            </div>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {list.map((v) => <VehicleCard key={v.id} vehicle={v} />)}
            </div>
          </>
        )}
      </div>
    </>
  );
}
