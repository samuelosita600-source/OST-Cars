import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { PageHero, Section } from "@/components/site/Section";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { formatNaira } from "@/libs/format";
import { useAuth } from "@/libs/auth";
import { useAllVehicles, useEnquiries, useEnquiryStatus, useVehicleMutations, type VehicleInput, type Enquiry } from "@/libs/vehicles-admin";
import { VehicleForm } from "@/components/admin/VehicleForm";
import type { Vehicle } from "@/data/vehicles";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin Dashboard | OST Luxury Cars" },
      { name: "description", content: "Manage inventory, enquiries, test drives and dealership settings for OST Luxury Cars." },
      { property: "og:title", content: "Admin Dashboard | OST Luxury Cars" },
      { property: "og:description", content: "Manage inventory, enquiries, test drives and dealership settings." },
    ],
  }),
  component: AdminPage,
});

const SECTIONS = ["Overview", "Inventory", "Enquiries"] as const;
const STATUSES = ["New", "In progress", "Closed"] as const;

function AdminPage() {
  const { user, isAdmin, loading, profile, signOut } = useAuth();
  const navigate = useNavigate();
  const [section, setSection] = useState<(typeof SECTIONS)[number]>("Overview");
  const [editing, setEditing] = useState<Vehicle | null | undefined>(undefined);

  const { data: vehicles = [], isLoading } = useAllVehicles();
  const { data: enquiries = [] } = useEnquiries(Boolean(isAdmin));
  const { create, update, remove } = useVehicleMutations();
  const statusMutation = useEnquiryStatus();

  useEffect(() => {
    if (!loading && !user) void navigate({ to: "/login", replace: true });
  }, [loading, user, navigate]);

  if (loading || !user) {
    return <Section><div className="glass-panel rounded-lg p-12 text-center text-sm text-muted-foreground">Checking your access…</div></Section>;
  }

  if (!isAdmin) {
    return (
      <>
        <PageHero eyebrow="Admin" title="Restricted area." lead="This dashboard is limited to OST Luxury Cars administrators." />
        <Section>
          <div className="glass-panel rounded-lg p-12 text-center">
            <p className="text-sm text-muted-foreground">
              You are signed in as {profile?.email ?? user.email}, which does not have administrator access.
            </p>
            <Button asChild variant="chrome" size="lg" className="mt-6"><Link to="/account">Go to your account</Link></Button>
          </div>
        </Section>
      </>
    );
  }

  const available = vehicles.filter((v: Vehicle) => v.availability === "Available").length;
  const reserved = vehicles.filter((v: Vehicle) => v.availability === "Reserved").length;
  const sold = vehicles.filter((v: Vehicle) => v.availability === "Sold").length;
  const stats: Array<[string, string]> = [
    ["Total vehicles", String(vehicles.length)],
    ["Available", String(available)],
    ["Reserved", String(reserved)],
    ["Sold", String(sold)],
    ["Total enquiries", String(enquiries.length)],
    ["New enquiries", String(enquiries.filter((e: Enquiry) => e.status === "New").length)],
    ["Test drives", String(enquiries.filter((e: Enquiry) => e.kind === "Test drive").length)],
    ["Featured listings", String(vehicles.filter((v: Vehicle) => v.featured).length)],
  ];

  async function save(input: VehicleInput) {
    if (editing) {
      await update.mutateAsync({ id: editing.id, input });
      toast.success("Vehicle updated");
    } else {
      await create.mutateAsync(input);
      toast.success("Vehicle added");
    }
  }

  return (
    <>
      <PageHero eyebrow="Admin" title="Dealership control room." lead="Add, edit and retire listings, and work through every client enquiry." />
      <Section>
        <div className="mb-6 flex flex-wrap gap-3">
          <Button variant="chrome" size="lg" onClick={async () => { await signOut(); void navigate({ to: "/login", replace: true }); }}>Sign out</Button>
        </div>

        <div className="lg:flex lg:gap-8">
          <nav aria-label="Admin sections" className="mb-6 flex flex-wrap gap-2 lg:mb-0 lg:w-56 lg:shrink-0 lg:flex-col">
            {SECTIONS.map((s) => (
              <button key={s} type="button" onClick={() => setSection(s)}
                className={`rounded-full px-4 py-2.5 text-left text-[0.66rem] tracking-[0.16em] uppercase transition-colors ${section === s ? "bg-primary text-primary-foreground" : "border border-border text-muted-foreground hover:text-foreground"}`}>
                {s}
              </button>
            ))}
          </nav>

          <div className="min-w-0 flex-1">
            {section === "Overview" && (
              <>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                  {stats.map(([l, v]) => (
                    <div key={l} className="glass-panel rounded-lg p-5">
                      <p className="text-[0.6rem] tracking-[0.2em] uppercase text-muted-foreground">{l}</p>
                      <p className="font-display mt-2 text-3xl text-chrome-gradient">{v}</p>
                    </div>
                  ))}
                </div>
                <div className="glass-panel mt-6 rounded-lg p-6">
                  <h2 className="font-display text-xl">Recent activity</h2>
                  {enquiries.length === 0 ? (
                    <p className="mt-4 text-sm text-muted-foreground">No enquiries yet.</p>
                  ) : (
                    <ul className="mt-4 space-y-3 text-sm text-muted-foreground">
                      {enquiries.slice(0, 6).map((e: Enquiry) => {
                        const v = vehicles.find((x: Vehicle) => x.id === e.vehicle_id);
                        return (
                          <li key={e.id}>
                            {e.kind} — {e.name}
                            {v ? ` · ${v.year} ${v.brand} ${v.model}` : ""} · {new Date(e.created_at).toLocaleDateString("en-NG")}
                          </li>
                        );
                      })}
                    </ul>
                  )}
                </div>
              </>
            )}

            {section === "Inventory" && (
              <div className="glass-panel overflow-x-auto rounded-lg">
                <div className="flex flex-wrap items-center justify-between gap-3 p-5">
                  <h2 className="font-display text-xl">Inventory management</h2>
                  <Button variant="hero" size="lg" onClick={() => setEditing(null)}>Add vehicle</Button>
                </div>
                {isLoading ? (
                  <p className="p-5 text-sm text-muted-foreground">Loading inventory…</p>
                ) : (
                  <table className="w-full min-w-[46rem] text-sm">
                    <thead>
                      <tr className="border-y border-border text-left text-[0.6rem] tracking-[0.2em] uppercase text-muted-foreground">
                        <th className="p-4">Ref</th><th className="p-4">Vehicle</th><th className="p-4">Price</th>
                        <th className="p-4">Status</th><th className="p-4">Featured</th><th className="p-4">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {vehicles.map((v: Vehicle) => (
                        <tr key={v.id} className="border-b border-border/60">
                          <td className="p-4 text-muted-foreground">{v.ref}</td>
                          <td className="p-4">{v.year} {v.brand} {v.model}</td>
                          <td className="p-4">{formatNaira(v.price)}</td>
                          <td className="p-4">{v.availability}</td>
                          <td className="p-4">{v.featured ? "Yes" : "—"}</td>
                          <td className="p-4">
                            <div className="flex gap-2">
                              <Button variant="secondary" size="sm" onClick={() => setEditing(v)}>Edit</Button>
                              <Button variant="ghost" size="sm"
                                onClick={async () => {
                                  if (!window.confirm(`Delete ${v.year} ${v.brand} ${v.model}?`)) return;
                                  try {
                                    await remove.mutateAsync(v.id);
                                    toast.success("Vehicle deleted");
                                  } catch (err) {
                                    toast.error("Could not delete", { description: err instanceof Error ? err.message : undefined });
                                  }
                                }}>
                                Delete
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            )}

            {section === "Enquiries" && (
              <div className="glass-panel rounded-lg p-6">
                <h2 className="font-display text-xl">Client enquiries</h2>
                {enquiries.length === 0 ? (
                  <p className="mt-4 text-sm text-muted-foreground">No enquiries yet.</p>
                ) : (
                  <ul className="mt-5 divide-y divide-border">
                    {enquiries.map((e: Enquiry) => {
                      const v = vehicles.find((x: Vehicle) => x.id === e.vehicle_id);
                      return (
                        <li key={e.id} className="py-5">
                          <div className="flex flex-wrap items-center justify-between gap-3">
                            <div>
                              <p className="text-sm">{e.kind}{v ? ` — ${v.year} ${v.brand} ${v.model}` : ""}</p>
                              <p className="mt-1 text-xs text-muted-foreground">
                                {e.name} · {e.email}{e.phone ? ` · ${e.phone}` : ""}
                              </p>
                            </div>
                            <select
                              value={e.status}
                              onChange={(ev) => statusMutation.mutate({ id: e.id, status: ev.target.value })}
                              className="rounded-full border border-border bg-transparent px-3 py-1.5 text-[0.62rem] tracking-[0.16em] uppercase text-pearl"
                            >
                              {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                            </select>
                          </div>
                          {e.message && <p className="mt-3 text-xs text-muted-foreground">{e.message}</p>}
                          <p className="mt-2 text-[0.6rem] tracking-[0.2em] uppercase text-muted-foreground">
                            {new Date(e.created_at).toLocaleString("en-NG")}
                          </p>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </div>
            )}
          </div>
        </div>
      </Section>

      {editing !== undefined && (
        <VehicleForm vehicle={editing} onClose={() => setEditing(undefined)} onSave={save} />
      )}
    </>
  );
}
