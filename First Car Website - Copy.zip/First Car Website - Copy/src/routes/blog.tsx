import { createFileRoute } from "@tanstack/react-router";
import { PageHero, Section } from "@/components/site/Section";
import { Button } from "@/components/ui/button";
import { Field, inputClass, textareaClass } from "@/components/site/FormBits";
import { useState } from "react";
import { toast } from "sonner";
import { POSTS } from "@/data/content";

export const Route = createFileRoute("/blog")({
  head: () => ({
    meta: [
      { title: "Journal — Automotive News & Ownership Guides | OST Luxury Cars" },
      { name: "description", content: "Ownership guides, buying advice and market notes for luxury vehicle owners in Nigeria, from the OST Luxury Cars journal." },
      { property: "og:title", content: "Journal — Automotive News & Ownership Guides | OST Luxury Cars" },
      { property: "og:description", content: "Ownership guides, buying advice and market notes for luxury vehicle owners in Nigeria, from the OST Luxury Cars journal." },
    ],
  }),
  component: BlogPage,
});

function BlogPage() {
  return (
    <>
      <PageHero eyebrow="Journal" title="Automotive news & ownership guides." lead="Practical reading for luxury vehicle buyers and owners in Nigeria." />
      <Section>
        <div className="grid gap-6 lg:grid-cols-2">
          {POSTS.map((p, i) => (
            <article key={p.slug} className="reveal glass-panel rounded-lg p-8" style={{ transitionDelay: `${i * 60}ms` }}>
              <p className="eyebrow">{p.category} · {p.date} · {p.readTime}</p>
              <h2 className="font-display mt-3 text-2xl leading-snug">{p.title}</h2>
              <p className="mt-3 text-sm text-muted-foreground">{p.excerpt}</p>
              <div className="mt-5 space-y-3 text-sm leading-relaxed text-foreground/85">
                {p.body.map((para) => <p key={para.slice(0, 24)}>{para}</p>)}
              </div>
            </article>
          ))}
        </div>
      </Section>
    </>
  );
}
