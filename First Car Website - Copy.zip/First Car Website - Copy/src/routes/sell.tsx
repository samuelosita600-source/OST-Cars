import { createFileRoute } from "@tanstack/react-router";
import { PageHero, Section } from "@/components/site/Section";
import { Button } from "@/components/ui/button";
import { Field, inputClass, textareaClass } from "@/components/site/FormBits";
import { useState } from "react";
import { toast } from "sonner";
import { whatsappLink } from "@/lib/format";

export const Route = createFileRoute("/sell")({
  head: () => ({
    meta: [
      { title: "Sell or Trade In Your Car | OST Luxury Cars Nigeria" },
      { name: "description", content: "Sell your car or trade it in against your next luxury vehicle. Share make, model, year, mileage and condition for an indicative valuation." },
      { property: "og:title", content: "Sell or Trade In Your Car | OST Luxury Cars Nigeria" },
      { property: "og:description", content: "Sell your car or trade it in against your next luxury vehicle. Share make, model, year, mileage and condition for an indicative valuation." },
    ],
  }),
  component: SellPage,
});

function SellPage() {
  const [done, setDone] = useState(false);
  return (
    <>
      <PageHero eyebrow="Sell or trade-in" title="Turn your current car into your next one."
        lead="Share the details and we revert with an indicative valuation range and inspection next steps." />
      <Section>
        {done ? (
          <div className="glass-panel rounded-lg p-12 text-center">
            <h2 className="font-display text-3xl">Valuation request received</h2>
            <p className="mt-3 text-sm text-muted-foreground">We will contact you with an indicative range shortly.</p>
            <Button variant="chrome" size="lg" className="mt-6" onClick={() => setDone(false)}>Submit another</Button>
          </div>
        ) : (
          <form className="glass-panel grid gap-4 rounded-lg p-7 sm:grid-cols-2"
            onSubmit={(e) => { e.preventDefault(); setDone(true); toast.success("Valuation request sent"); }}>
            <Field label="Make"><input required className={inputClass} placeholder="e.g. Lexus" /></Field>
            <Field label="Model"><input required className={inputClass} placeholder="e.g. RX 350" /></Field>
            <Field label="Year"><input required type="number" min={1990} max={2026} className={inputClass} placeholder="2021" /></Field>
            <Field label="Mileage (km)"><input required type="number" min={0} className={inputClass} placeholder="48000" /></Field>
            <Field label="Condition"><select className={inputClass}><option>Excellent</option><option>Good</option><option>Fair</option><option>Needs work</option></select></Field>
            <Field label="Expected price (₦)"><input type="number" className={inputClass} placeholder="45000000" /></Field>
            <Field label="Photos" hint="Upload configuration pending — you can also send photos on WhatsApp.">
              <input type="file" multiple className={inputClass + " pt-2.5"} />
            </Field>
            <Field label="Preferred contact"><select className={inputClass}><option>WhatsApp</option><option>Phone call</option><option>Email</option></select></Field>
            <Field label="Full name"><input required className={inputClass} placeholder="Your name" /></Field>
            <Field label="Phone / WhatsApp"><input required type="tel" className={inputClass} placeholder="080 0000 0000" /></Field>
            <div className="sm:col-span-2"><Field label="Additional details"><textarea className={textareaClass} /></Field></div>
            <div className="sm:col-span-2 flex flex-wrap gap-3">
              <Button type="submit" variant="hero" size="xl">Request valuation</Button>
              <Button asChild variant="whatsapp" size="xl">
                <a href={whatsappLink("Hello OST Luxury Cars, I would like to sell or trade in my vehicle.")} target="_blank" rel="noopener noreferrer">Send photos on WhatsApp</a>
              </Button>
            </div>
          </form>
        )}
      </Section>
    </>
  );
}
