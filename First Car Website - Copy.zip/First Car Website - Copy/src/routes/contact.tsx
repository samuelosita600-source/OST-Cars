import { createFileRoute } from "@tanstack/react-router";
import { PageHero, Section } from "@/components/site/Section";
import { Button } from "@/components/ui/button";
import { Field, inputClass, textareaClass } from "@/components/site/FormBits";
import { useState } from "react";
import { toast } from "sonner";
import { whatsappLink, CONTACT_EMAIL, CONTACT_PHONE, SHOWROOM_ADDRESS } from "@/lib/format";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact OST Luxury Cars — Kugbo, Abuja" },
      { name: "description", content: "Contact OST Luxury Cars by WhatsApp, phone or email for vehicle enquiries, inspections, sourcing and financing guidance in Nigeria." },
      { property: "og:title", content: "Contact OST Luxury Cars — Kugbo, Abuja" },
      { property: "og:description", content: "Contact OST Luxury Cars by WhatsApp, phone or email for vehicle enquiries, inspections, sourcing and financing guidance in Nigeria." },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  return (
    <>
      <PageHero eyebrow="Contact" title="Talk to a concierge." lead="WhatsApp is the fastest route. We reply during showroom hours, Lagos time." />
      <Section>
        <div className="grid gap-6 lg:grid-cols-[1.2fr_1fr]">
          <form className="glass-panel grid gap-4 rounded-lg p-7 sm:grid-cols-2"
            onSubmit={(e) => { e.preventDefault(); toast.success("Message sent", { description: "We will respond shortly." }); }}>
            <Field label="Full name"><input required className={inputClass} placeholder="Your name" /></Field>
            <Field label="Phone / WhatsApp"><input required type="tel" className={inputClass} placeholder="080 0000 0000" /></Field>
            <Field label="Email"><input type="email" className={inputClass} placeholder="you@example.com" /></Field>
            <Field label="Subject">
              <select className={inputClass}>
                <option>General enquiry</option><option>Vehicle enquiry</option><option>Request inspection</option>
                <option>Reserve a vehicle</option><option>Sourcing request</option><option>Financing</option>
              </select>
            </Field>
            <div className="sm:col-span-2"><Field label="Message"><textarea required className={textareaClass} placeholder="How can we help?" /></Field></div>
            <div className="sm:col-span-2 flex flex-wrap gap-3">
              <Button type="submit" variant="hero" size="xl">Send message</Button>
              <Button asChild variant="whatsapp" size="xl">
                <a href={whatsappLink("Hello OST Luxury Cars, I have an enquiry.")} target="_blank" rel="noopener noreferrer">WhatsApp concierge</a>
              </Button>
            </div>
            <p className="sm:col-span-2 text-xs text-muted-foreground">
              We use your details only to respond to this enquiry.
            </p>
          </form>

          <div className="space-y-4">
            <div className="glass-panel rounded-lg p-7">
              <h2 className="font-display text-2xl">Showroom</h2>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                {SHOWROOM_ADDRESS}. Viewings are by appointment.
                <br />
                <br />
                Phone / WhatsApp:{" "}
                <a href={`tel:${CONTACT_PHONE}`} className="hover:text-foreground">
                  {CONTACT_PHONE}
                </a>
                <br />
                Email:{" "}
                <a href={`mailto:${CONTACT_EMAIL}`} className="hover:text-foreground">
                  {CONTACT_EMAIL}
                </a>
              </p>
            </div>
            <div className="glass-panel rounded-lg p-7">
              <h2 className="font-display text-2xl">Hours</h2>
              <p className="mt-3 text-sm text-muted-foreground">Mon – Fri: 9:00am – 6:00pm<br />Saturday: 10:00am – 5:00pm<br />Sunday: By appointment</p>
            </div>
            <div className="overflow-hidden rounded-lg border border-border">
              <iframe
                title="OST Luxury Cars showroom location — Kugbo, Abuja"
                src="https://www.google.com/maps?q=Kugbo,+Abuja,+Nigeria&output=embed"
                className="h-56 w-full"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>
        </div>
      </Section>
    </>
  );
}
