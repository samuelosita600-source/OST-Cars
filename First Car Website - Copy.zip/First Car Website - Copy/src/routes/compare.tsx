import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHero } from "@/components/site/Section";
import { Button } from "@/components/ui/button";
import { getVehiclesByIds, type Vehicle } from "@/data/vehicles";
import { listVehicles } from "@/libs/vehicles.functions";
import { formatMileage, formatNaira } from "@/libs/format";
import { useCompare } from "@/libs/store";

export const Route = createFileRoute("/compare")({
  loader: () => listVehicles(),
  head: () => ({
    meta: [
      { title: "Compare Luxury Cars Side by Side | OST Luxury Cars" },
      { name: "description", content: "Compare 2–4 luxury vehicles on price, year, mileage, engine, transmission, fuel and features — all in Naira." },
      { property: "og:title", content: "Compare Luxury Cars | OST Luxury Cars" },
      { property: "og:description", content: "See exactly where your shortlisted vehicles differ." },
    ],
  }),
  component: ComparePage,
});

const ROWS: Array<[string, (v: Vehicle) => string]> = [
  ["Price", (v) => formatNaira(v.price)],
  ["Year", (v) => String(v.year)],
  ["Mileage", (v) => formatMileage(v.mileage)],
  ["Engine", (v) => v.engine],
  ["Power", (v) => v.power],
  ["Transmission", (v) => v.transmission],
  ["Fuel", (v) => v.fuel],
  ["Body type", (v) => v.bodyType],
  ["0–100 km/h", (v) => v.acceleration],
  ["Drivetrain", (v) => v.drivetrain],
  ["Condition", (v) => v.condition],
  ["Availability", (v) => v.availability],
  ["Inspection", (v) => v.inspection],
  ["Key features", (v) => v.features.slice(0, 4).join(", ")],
];

function ComparePage() {
  const all = Route.useLoaderData();
  const { compare, removeCompare, clearCompare } = useCompare();
  const list = getVehiclesByIds(compare, all);

  return (
    <>
      <PageHero eyebrow="Compare" title="Side by side, no guesswork." lead="Add up to four vehicles from the collection. Differences are highlighted per row." />
      <div className="mx-auto max-w-7xl px-5 py-12 sm:px-6">
        {list.length === 0 ? (
          <div className="glass-panel rounded-lg p-12 text-center">
            <h2 className="font-display text-2xl">Your compare list is empty</h2>
            <p className="mt-3 text-sm text-muted-foreground">Tap the compare icon on any vehicle card to add it here.</p>
            <Button asChild variant="hero" size="lg" className="mt-6"><Link to="/inventory">Browse the collection</Link></Button>
          </div>
        ) : (
          <>
            <div className="mb-5 flex items-center justify-between">
              <p className="text-sm text-muted-foreground">{list.length} of 4 selected</p>
              <Button variant="chrome" size="lg" onClick={clearCompare}>Clear all</Button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[42rem] border-collapse text-sm">
                <caption className="sr-only">Vehicle comparison</caption>
                <thead>
                  <tr>
                    <th scope="col" className="sticky left-0 z-10 bg-abyss px-3 py-4 text-left eyebrow">Specification</th>
                    {list.map((v) => (
                      <th key={v.id} scope="col" className="min-w-52 px-3 py-4 text-left align-top">
                        <img src={v.images[0]} alt="" loading="lazy" className="mb-3 h-24 w-full rounded-md object-cover" />
                        <span className="font-display block text-base">{v.brand} {v.model}</span>
                        <button type="button" onClick={() => removeCompare(v.id)} className="mt-2 text-[0.62rem] tracking-[0.2em] uppercase text-muted-foreground hover:text-destructive">
                          Remove
                        </button>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {ROWS.map(([label, get]) => {
                    const values = list.map(get);
                    const differs = new Set(values).size > 1;
                    return (
                      <tr key={label} className="border-t border-border">
                        <th scope="row" className="sticky left-0 z-10 bg-abyss px-3 py-3 text-left text-[0.62rem] tracking-[0.2em] uppercase text-muted-foreground">
                          {label}
                        </th>
                        {values.map((val, i) => (
                          <td key={i} className={`px-3 py-3 ${differs ? "text-pearl" : "text-foreground"}`}>{val}</td>
                        ))}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <p className="mt-6 text-xs text-muted-foreground">Highlighted values differ between the selected vehicles.</p>
          </>
        )}
      </div>
    </>
  );
}
