import { createFileRoute, Link, useNavigate, useRouter } from "@tanstack/react-router";
import { PageHero, Section } from "@/components/site/Section";
import { Button } from "@/components/ui/button";
import { Field, inputClass } from "@/components/site/FormBits";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/libs/auth";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Sign In or Create an Account | OST Luxury Cars" },
      { name: "description", content: "Sign in to save vehicles, track enquiries, test-drive bookings and finance requests with OST Luxury Cars." },
      { property: "og:title", content: "Sign In or Create an Account | OST Luxury Cars" },
      { property: "og:description", content: "Sign in to save vehicles, track enquiries, test-drive bookings and finance requests with OST Luxury Cars." },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [busy, setBusy] = useState(false);
  const [checkEmail, setCheckEmail] = useState(false);
  const { user, isAdmin } = useAuth();
  const navigate = useNavigate();
  const router = useRouter();

  useEffect(() => {
    if (user) void navigate({ to: isAdmin ? "/admin" : "/account", replace: true });
  }, [user, isAdmin, navigate]);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const email = String(form.get("email") ?? "").trim();
    const password = String(form.get("password") ?? "");
    setBusy(true);
    try {
      if (mode === "signup") {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: `${window.location.origin}/login`,
            data: {
              full_name: String(form.get("name") ?? ""),
              phone: String(form.get("phone") ?? ""),
            },
          },
        });
        if (error) throw error;
        if (!data.session) {
          setCheckEmail(true);
          return;
        }
        toast.success("Account created");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success("Welcome back");
      }
      router.invalidate();
    } catch (err) {
      toast.error(mode === "signup" ? "Could not create account" : "Could not sign in", {
        description: err instanceof Error ? err.message : undefined,
      });
    } finally {
      setBusy(false);
    }
  }

  async function google() {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: `${window.location.origin}/account`,
        queryParams: {
          access_type: "offline",
          prompt: "consent",
        },
      },
    });
    if (error) {
      toast.error("Google sign-in failed", { description: error.message });
      return;
    }
    router.invalidate();
  }

  return (
    <>
      <PageHero
        eyebrow="Customer account"
        title={mode === "login" ? "Welcome back." : "Create your account."}
        lead="Save vehicles, track enquiries and manage bookings in one place."
      />
      <Section>
        <div className="mx-auto max-w-md">
          {checkEmail ? (
            <div className="glass-panel rounded-lg p-8 text-center">
              <h2 className="font-display text-2xl">Confirm your email</h2>
              <p className="mt-3 text-sm text-muted-foreground">
                We sent you a confirmation link. Open it to activate your OST Luxury Cars account, then sign in.
              </p>
              <Button variant="chrome" size="lg" className="mt-6" onClick={() => { setCheckEmail(false); setMode("login"); }}>
                Back to sign in
              </Button>
            </div>
          ) : (
            <>
              <div className="mb-5 flex gap-2">
                {(["login", "signup"] as const).map((m) => (
                  <button key={m} type="button" onClick={() => setMode(m)}
                    className={`flex-1 rounded-full px-4 py-2.5 text-[0.68rem] tracking-[0.18em] uppercase transition-colors ${mode === m ? "bg-primary text-primary-foreground" : "border border-border text-muted-foreground"}`}>
                    {m === "login" ? "Sign in" : "Create account"}
                  </button>
                ))}
              </div>
              <form className="glass-panel space-y-4 rounded-lg p-7" onSubmit={onSubmit}>
                {mode === "signup" && (
                  <Field label="Full name"><input name="name" required className={inputClass} placeholder="Your name" /></Field>
                )}
                <Field label="Email"><input name="email" required type="email" className={inputClass} placeholder="you@example.com" /></Field>
                {mode === "signup" && (
                  <Field label="Phone / WhatsApp"><input name="phone" type="tel" className={inputClass} placeholder="080 0000 0000" /></Field>
                )}
                <Field label="Password">
                  <input name="password" required minLength={8} type="password" className={inputClass} placeholder="••••••••" />
                </Field>
                <Button type="submit" variant="hero" size="xl" className="w-full" disabled={busy}>
                  {busy ? "Please wait…" : mode === "login" ? "Sign in" : "Create account"}
                </Button>
                <div className="flex items-center gap-3 text-[0.6rem] tracking-[0.2em] uppercase text-muted-foreground">
                  <span className="h-px flex-1 bg-border" /> or <span className="h-px flex-1 bg-border" />
                </div>
                <Button type="button" variant="chrome" size="xl" className="w-full" onClick={google}>
                  Continue with Google to sign in or create an account
                </Button>
              </form>
            </>
          )}
          <p className="mt-6 text-center text-sm text-muted-foreground">
            Already signed in? <Link to="/account" className="text-pearl hover:underline">Go to your dashboard</Link>
          </p>
        </div>
      </Section>
    </>
  );
}
