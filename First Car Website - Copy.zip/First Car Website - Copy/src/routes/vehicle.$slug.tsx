import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { Heart, GitCompareArrows, MessageCircle, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { VehicleCard } from "@/components/vehicles/VehicleCard";
import { getVehicleBySlug } from "@/libs/vehicles.functions";
import { EnquiryDialog } from "@/components/vehicles/EnquiryDialog";
import { formatMileage, formatNaira, monthlyPayment, whatsappLink } from "@/libs/format";
import { useCompare, useFavorites } from "@/libs/store";
import type { Vehicle } from "@/data/vehicles";

export const Route = createFileRoute("/vehicle/$slug")({
  loader: async ({ params }) => {
    const result = await getVehicleBySlug({ data: { slug: params.slug } });
    if (!result) throw notFound();
    return result;
  },
  head: ({ loaderData }) => {
    if (!loaderData) return { meta: [{ title: "Vehicle unavailable | OST Luxury Cars" }, { name: "robots", content: "noindex" }] };
    const v = loaderData.vehicle;
    const title = `${v.year} ${v.brand} ${v.model} — ${formatNaira(v.price)} | OST Luxury Cars`;
    const description = `${v.condition} ${v.year} ${v.brand} ${v.model} in ${v.exteriorColour}. ${v.engine}, ${v.power}, ${formatMileage(v.mileage)}. Available in ${v.location}.`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
      ],
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Car",
            name: `${v.year} ${v.brand} ${v.model}`,
            brand: v.brand,
            modelDate: v.year,
            vehicleTransmission: v.transmission,
            fuelType: v.fuel,
            mileageFromOdometer: { "@type": "QuantitativeValue", value: v.mileage, unitCode: "KMT" },
            offers: { "@type": "Offer", price: v.price, priceCurrency: "NGN", availability: v.availability },
          }),
        },
      ],
    };
  },
  component: VehiclePage,
});

function VehiclePage() {
  const { vehicle: v, similar } = Route.useLoaderData();
  const [active, setActive] = useState(0);
  const { favorites, toggleFavorite } = useFavorites();
  const { compare, toggleCompare } = useCompare();
  const estimate = monthlyPayment(v.price * 0.7, 24, 48);
  const enquiry = `Hello OST Luxury Cars, I am interested in the ${v.year} ${v.brand} ${v.model} (Ref ${v.ref}).`;

  const specs: Array<[string, string]> = [
    ["Year", String(v.year)], ["Body type", v.bodyType], ["Engine", v.engine], ["Power", v.power],
    ["Transmission", v.transmission], ["Fuel", v.fuel], ["Drivetrain", v.drivetrain], ["Mileage", formatMileage(v.mileage)],
    ["0–100 km/h", v.acceleration], ["Seats", String(v.seats)], ["Exterior", v.exteriorColour], ["Interior", v.interiorColour],
    ["Condition", v.condition], ["Location", v.location], ["Reference", v.ref], ["VIN", v.vin],
  ];

  return (
    <>
      <section className="relative h-[70vh] min-h-[26rem] overflow-hidden">
        <img src={v.images[active]} alt={`${v.year} ${v.brand} ${v.model}`} width={1600} height={1000}
          className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-abyss via-abyss/50 to-abyss/40" />
        <div className="absolute inset-x-0 bottom-0">
          <div className="mx-auto max-w-7xl px-5 pb-10 sm:px-6">
            <p className="eyebrow">{v.brand} · {v.availability}</p>
            <h1 className="font-display mt-3 text-4xl leading-tight sm:text-6xl">
              <span className="text-chrome-gradient">{v.year} {v.model}</span>
            </h1>
            <p className="mt-3 text-2xl text-pearl">{formatNaira(v.price)}</p>
          </div>
        </div>
      </section>

      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-14 sm:px-6 lg:grid-cols-[1fr_22rem]">
        <div className="min-w-0">
          <div className="flex gap-3 overflow-x-auto pb-2">
            {v.images.map((img: string, i: number) => (
              <button key={i} type="button" onClick={() => setActive(i)} aria-label={`View image ${i + 1}`}
                className={`h-20 w-32 shrink-0 overflow-hidden rounded-md border transition-all ${i === active ? "border-pearl" : "border-border opacity-60 hover:opacity-100"}`}>
                <img src={img} alt="" loading="lazy" className="h-full w-full object-cover" />
              </button>
            ))}
          </div>

          <h2 className="font-display mt-12 text-3xl">Technical specification</h2>
          <dl className="mt-6 grid grid-cols-2 gap-x-6 gap-y-5 sm:grid-cols-3">
            {specs.map(([k, val]) => (
              <div key={k} className="border-t border-border pt-3">
                <dt className="text-[0.6rem] tracking-[0.2em] uppercase text-muted-foreground">{k}</dt>
                <dd className="mt-1 text-sm">{val}</dd>
              </div>
            ))}
          </dl>

          <h2 className="font-display mt-14 text-3xl">Feature highlights</h2>
          <ul className="mt-6 grid gap-3 sm:grid-cols-2">
            {v.features.map((f: string) => (
              <li key={f} className="glass-panel rounded-md px-4 py-3 text-sm">{f}</li>
            ))}
          </ul>

          <div className="glass-panel mt-14 rounded-lg p-7">
            <ShieldCheck className="h-6 w-6 text-pearl" />
            <h2 className="font-display mt-4 text-2xl">Ownership & inspection confidence</h2>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              Status: {v.inspection}. This vehicle is presented as {v.condition.toLowerCase()} and its documented history is
              available on request. We recommend an in-person inspection before purchase — we will arrange it.
            </p>
          </div>

          <div className="glass-panel mt-6 rounded-lg p-7">
            <p className="eyebrow">Finance estimate</p>
            <p className="font-display mt-3 text-3xl text-chrome-gradient">{formatNaira(estimate)}<span className="text-sm"> / month</span></p>
            <p className="mt-3 text-xs leading-relaxed text-muted-foreground">
              Based on a 30% deposit over 48 months at an indicative 24% annual rate. Estimate only — subject to lender
              assessment and approval. <Link to="/financing" className="text-pearl hover:underline">Adjust the figures</Link>.
            </p>
          </div>

          {similar.length > 0 && (
            <>
              <h2 className="font-display mt-16 text-3xl">Similar vehicles</h2>
              <div className="mt-6 grid gap-4 sm:grid-cols-3">
                {similar.map((s: Vehicle) => <VehicleCard key={s.id} vehicle={s} />)}
              </div>
            </>
          )}
        </div>

        <aside className="lg:sticky lg:top-24 lg:self-start">
          <div className="glass-panel rounded-lg p-6">
            <p className="eyebrow">Take the next step</p>
            <p className="font-display mt-2 text-2xl text-chrome-gradient">{formatNaira(v.price)}</p>
            <div className="mt-5 space-y-2.5">
              <EnquiryDialog vehicle={v} className="w-full" />
              <Button asChild variant="hero" size="lg" className="w-full"><Link to="/test-drive">Book Test Drive</Link></Button>
              <Button asChild variant="whatsapp" size="lg" className="w-full">
                <a href={whatsappLink(enquiry)} target="_blank" rel="noopener noreferrer">
                  <MessageCircle className="h-4 w-4" /> Chat on WhatsApp
                </a>
              </Button>
              <EnquiryDialog vehicle={v} kind="Inspection" label="Request Inspection" variant="chrome" className="w-full" />
              <EnquiryDialog vehicle={v} kind="Reservation" label="Reserve This Car" variant="chrome" className="w-full" />
              <Button asChild variant="chrome" size="lg" className="w-full"><Link to="/financing">Get Finance Estimate</Link></Button>
              <div className="grid grid-cols-2 gap-2.5">
                <Button variant="secondary" size="lg" onClick={() => toggleFavorite(v.id)}>
                  <Heart className={`h-4 w-4 ${favorites.includes(v.id) ? "fill-current text-pearl" : ""}`} />
                  {favorites.includes(v.id) ? "Saved" : "Save"}
                </Button>
                <Button variant="secondary" size="lg" onClick={() => toggleCompare(v.id)}>
                  <GitCompareArrows className="h-4 w-4" />
                  {compare.includes(v.id) ? "Added" : "Compare"}
                </Button>
              </div>
            </div>
          </div>
        </aside>
      </div>

      <div className="glass-panel fixed inset-x-0 bottom-0 z-40 flex items-center gap-2 border-t border-border p-3 lg:hidden">
        <div className="min-w-0 flex-1">
          <p className="truncate text-[0.65rem] text-muted-foreground">{v.year} {v.brand}</p>
          <p className="truncate text-sm text-pearl">{formatNaira(v.price)}</p>
        </div>
        <Button asChild variant="whatsapp" size="lg">
          <a href={whatsappLink(enquiry)} target="_blank" rel="noopener noreferrer"><MessageCircle className="h-4 w-4" /> Enquire</a>
        </Button>
        <Button asChild variant="hero" size="lg"><Link to="/test-drive">Test Drive</Link></Button>
      </div>
      <div className="h-20 lg:hidden" />
    </>
  );
}
