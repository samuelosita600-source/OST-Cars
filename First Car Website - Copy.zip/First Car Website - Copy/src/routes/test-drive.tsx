import { createFileRoute } from "@tanstack/react-router";
import { PageHero, Section } from "@/components/site/Section";
import { Button } from "@/components/ui/button";
import { Field, inputClass, textareaClass } from "@/components/site/FormBits";
import { useState } from "react";
import { toast } from "sonner";
import { listVehicles } from "@/libs/vehicles.functions";
import { submitEnquiry } from "@/libs/vehicles-admin";
import { useAuth } from "@/libs/auth";
import type { Vehicle } from "@/data/vehicles";

export const Route = createFileRoute("/test-drive")({
  loader: () => listVehicles(),
  head: () => ({
    meta: [
      { title: "Book a Test Drive | OST Luxury Cars Nigeria" },
      { name: "description", content: "Book a test drive for any vehicle in the OST Luxury Cars collection. Choose your date, time and location in Nigeria." },
      { property: "og:title", content: "Book a Test Drive | OST Luxury Cars Nigeria" },
      { property: "og:description", content: "Book a test drive for any vehicle in the OST Luxury Cars collection. Choose your date, time and location in Nigeria." },
    ],
  }),
  component: TestDrivePage,
});

function TestDrivePage() {
  const vehicles = Route.useLoaderData();
  const { user, profile } = useAuth();
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);
  return (
    <>
      <PageHero eyebrow="Test drive" title="Experience it before you decide." lead="Choose a vehicle, date and location. We confirm by WhatsApp." />
      <Section>
        {done ? (
          <div className="glass-panel rounded-lg p-12 text-center">
            <h2 className="font-display text-3xl">Request received</h2>
            <p className="mt-3 text-sm text-muted-foreground">A concierge will confirm your slot on WhatsApp shortly.</p>
            <Button variant="chrome" size="lg" className="mt-6" onClick={() => setDone(false)}>Book another</Button>
          </div>
        ) : (
          <form className="glass-panel grid gap-4 rounded-lg p-7 sm:grid-cols-2"
            onSubmit={async (e) => {
              e.preventDefault();
              const form = new FormData(e.currentTarget);
              setBusy(true);
              try {
                await submitEnquiry({
                  vehicle_id: String(form.get("vehicle") ?? "") || null,
                  kind: "Test drive",
                  name: String(form.get("name") ?? ""),
                  email: String(form.get("email") ?? ""),
                  phone: String(form.get("phone") ?? ""),
                  message: `Location: ${form.get("location")} · Date: ${form.get("date")} ${form.get("time")}. ${form.get("notes") ?? ""}`,
                }, user?.id);
                setDone(true);
                toast.success("Test drive requested");
              } catch (err) {
                toast.error("Could not send request", { description: err instanceof Error ? err.message : undefined });
              } finally {
                setBusy(false);
              }
            }}>
            <Field label="Full name"><input name="name" required defaultValue={profile?.full_name ?? ""} className={inputClass} placeholder="Your name" /></Field>
            <Field label="Phone / WhatsApp"><input name="phone" required type="tel" defaultValue={profile?.phone ?? ""} className={inputClass} placeholder="080 0000 0000" /></Field>
            <Field label="Email"><input name="email" required type="email" defaultValue={profile?.email ?? user?.email ?? ""} className={inputClass} placeholder="you@example.com" /></Field>
            <Field label="Vehicle">
              <select name="vehicle" required className={inputClass}>
                {vehicles.slice(0, 60).map((v: Vehicle) => <option key={v.id} value={v.id}>{v.year} {v.brand} {v.model}</option>)}
              </select>
            </Field>
            <Field label="Location"><select name="location" className={inputClass}><option>Abuja (FCT)</option><option>Lagos</option><option>Port Harcourt</option><option>Other</option></select></Field>
            <Field label="Preferred date"><input name="date" required type="date" className={inputClass} /></Field>
            <Field label="Preferred time"><input name="time" required type="time" className={inputClass} /></Field>
            <div className="sm:col-span-2"><Field label="Notes"><textarea name="notes" className={textareaClass} placeholder="Anything we should prepare?" /></Field></div>
            <div className="sm:col-span-2"><Button type="submit" variant="hero" size="xl" disabled={busy}>{busy ? "Sending…" : "Request test drive"}</Button></div>
          </form>
        )}
      </Section>
    </>
  );
}
