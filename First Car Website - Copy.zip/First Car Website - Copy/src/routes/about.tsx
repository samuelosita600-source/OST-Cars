import { createFileRoute } from "@tanstack/react-router";
import { PageHero, Section } from "@/components/site/Section";
import { Button } from "@/components/ui/button";
import { Field, inputClass, textareaClass } from "@/components/site/FormBits";
import { useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About OST Luxury Cars — Curated Luxury Vehicles in Nigeria" },
      { name: "description", content: "OST Luxury Cars is a curated luxury automotive house serving Nigeria with verified sourcing, inspection, transparent Naira pricing and concierge service." },
      { property: "og:title", content: "About OST Luxury Cars — Curated Luxury Vehicles in Nigeria" },
      { property: "og:description", content: "OST Luxury Cars is a curated luxury automotive house serving Nigeria with verified sourcing, inspection, transparent Naira pricing and concierge service." },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <>
      <PageHero eyebrow="About" title="A curated automotive house, built for Nigeria."
        lead="OST Luxury Cars exists to remove the uncertainty from buying a luxury vehicle here — through curation, inspection and honest pricing." />
      <Section>
        <div className="grid gap-6 lg:grid-cols-3">
          {[
            ["Our approach", "We list fewer vehicles, better documented. Every unit is inspected and presented with its condition stated plainly."],
            ["Our clients", "Executives, founders, professionals and families who value discretion, reliability and a straightforward process."],
            ["Our promise", "Transparent Naira pricing, one dedicated contact, and no pressure. If a vehicle is not right for you, we will say so."],
          ].map(([t, c]) => (
            <div key={t} className="reveal glass-panel rounded-lg p-8">
              <h2 className="font-display text-2xl">{t}</h2>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{c}</p>
            </div>
          ))}
        </div>
        <div className="mt-14 grid gap-6 sm:grid-cols-3">
          {[["100+", "Vehicles curated"], ["6", "States served"], ["24/7", "WhatsApp concierge"]].map(([n, l]) => (
            <div key={l} className="reveal glass-panel rounded-lg p-8 text-center">
              <p className="font-display text-4xl"><span className="text-pearl-gradient">{n}</span></p>
              <p className="mt-2 text-[0.62rem] tracking-[0.22em] uppercase text-muted-foreground">{l}</p>
            </div>
          ))}
        </div>
        <p className="mt-10 max-w-2xl text-xs leading-relaxed text-muted-foreground">
          OST Luxury Cars makes no claims of official manufacturer partnership, escrow provision or guaranteed finance
          approval. Showroom: Kugbo, Abuja — nationwide delivery available.
        </p>
      </Section>
    </>
  );
}
