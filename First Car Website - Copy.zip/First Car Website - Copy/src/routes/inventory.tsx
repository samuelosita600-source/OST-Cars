import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { SlidersHorizontal, X } from "lucide-react";
import { z } from "zod";
import { PageHero } from "@/components/site/Section";
import { VehicleCard } from "@/components/vehicles/VehicleCard";
import { Button } from "@/components/ui/button";
import { Field, inputClass } from "@/components/site/FormBits";
import {
  AVAILABILITY_OPTIONS,
  BODY_TYPES,
  BRANDS,
  COLOUR_OPTIONS,
  ENGINE_OPTIONS,
  FUELS,
  LOCATION_OPTIONS,
  PRICE_MAX,
  PRICE_MIN,
  TRANSMISSIONS,
  type Vehicle,
} from "@/data/vehicles";
import { listVehicles } from "@/libs/vehicles.functions";
import { formatNairaShort } from "@/libs/format";

const searchSchema = z.object({
  brand: z.string().optional(),
  body: z.string().optional(),
  max: z.number().optional(),
});

export const Route = createFileRoute("/inventory")({
  validateSearch: searchSchema,
  loader: () => listVehicles(),
  head: () => ({
    meta: [
      { title: "Luxury Car Collection in Nigeria | OST Luxury Cars" },
      {
        name: "description",
        content:
          "Browse 100 inspected luxury vehicles priced in Naira — SUVs, executive sedans, performance cars, coupes, convertibles and EVs. Filter by brand, year, price, mileage and more.",
      },
      { property: "og:title", content: "Luxury Car Collection | OST Luxury Cars" },
      { property: "og:description", content: "Filterable inventory of curated luxury cars in Nigeria, priced in Naira." },
    ],
  }),
  component: Inventory,
});

const SORTS = [
  { value: "recommended", label: "Recommended" },
  { value: "newest", label: "Newest added" },
  { value: "price-asc", label: "Lowest price" },
  { value: "price-desc", label: "Highest price" },
  { value: "mileage", label: "Lowest mileage" },
  { value: "year", label: "Newest year" },
] as const;

function Inventory() {
  const search = Route.useSearch();
  const vehicles = Route.useLoaderData();
  const [q, setQ] = useState("");
  const [brand, setBrand] = useState(search.brand ?? "");
  const [model, setModel] = useState("");
  const [body, setBody] = useState(search.body ?? "");
  const [fuel, setFuel] = useState("");
  const [transmission, setTransmission] = useState("");
  const [engine, setEngine] = useState("");
  const [colour, setColour] = useState("");
  const [location, setLocation] = useState("");
  const [availability, setAvailability] = useState("");
  const [yearMin, setYearMin] = useState(2019);
  const [yearMax, setYearMax] = useState(2026);
  const [priceMax, setPriceMax] = useState(search.max ?? PRICE_MAX);
  const [mileageMax, setMileageMax] = useState(130000);
  const [featuredOnly, setFeaturedOnly] = useState(false);
  const [sort, setSort] = useState<string>("recommended");
  const [visible, setVisible] = useState(12);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const results = useMemo(() => {
    const list = vehicles.filter((v: Vehicle) => {
      if (q && !`${v.brand} ${v.model} ${v.year}`.toLowerCase().includes(q.toLowerCase())) return false;
      if (brand && v.brand !== brand) return false;
      if (model && !v.model.toLowerCase().includes(model.toLowerCase())) return false;
      if (body && v.bodyType !== body) return false;
      if (fuel && v.fuel !== fuel) return false;
      if (transmission && v.transmission !== transmission) return false;
      if (engine && v.engine !== engine) return false;
      if (colour && v.exteriorColour !== colour) return false;
      if (location && v.location !== location) return false;
      if (availability && v.availability !== availability) return false;
      if (v.year < yearMin || v.year > yearMax) return false;
      if (v.price > priceMax) return false;
      if (v.mileage > mileageMax) return false;
      if (featuredOnly && !v.featured) return false;
      return true;
    });
    const sorted = [...list];
    if (sort === "price-asc") sorted.sort((a, b) => a.price - b.price);
    if (sort === "price-desc") sorted.sort((a, b) => b.price - a.price);
    if (sort === "mileage") sorted.sort((a, b) => a.mileage - b.mileage);
    if (sort === "year") sorted.sort((a, b) => b.year - a.year);
    if (sort === "newest") sorted.sort((a, b) => b.dateAdded.localeCompare(a.dateAdded));
    if (sort === "recommended") sorted.sort((a, b) => Number(b.featured) - Number(a.featured));
    return sorted;
  }, [vehicles, q, brand, model, body, fuel, transmission, engine, colour, location, availability, yearMin, yearMax, priceMax, mileageMax, featuredOnly, sort]);

  const reset = () => {
    setQ(""); setBrand(""); setModel(""); setBody(""); setFuel(""); setTransmission(""); setEngine("");
    setColour(""); setLocation(""); setAvailability(""); setYearMin(2019); setYearMax(2026);
    setPriceMax(PRICE_MAX); setMileageMax(130000); setFeaturedOnly(false);
  };

  const filters = (
    <div className="space-y-4">
      <Field label="Search">
        <input className={inputClass} value={q} onChange={(e) => setQ(e.target.value)} placeholder="e.g. Range Rover" />
      </Field>
      <Field label="Brand">
        <select className={inputClass} value={brand} onChange={(e) => setBrand(e.target.value)}>
          <option value="">All brands</option>
          {BRANDS.map((b) => <option key={b} value={b}>{b}</option>)}
        </select>
      </Field>
      <Field label="Model">
        <input className={inputClass} value={model} onChange={(e) => setModel(e.target.value)} placeholder="Any model" />
      </Field>
      <Field label="Body type">
        <select className={inputClass} value={body} onChange={(e) => setBody(e.target.value)}>
          <option value="">All types</option>
          {BODY_TYPES.map((b) => <option key={b} value={b}>{b}</option>)}
        </select>
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Year from">
          <select className={inputClass} value={yearMin} onChange={(e) => setYearMin(Number(e.target.value))}>
            {Array.from({ length: 8 }, (_, i) => 2019 + i).map((y) => <option key={y} value={y}>{y}</option>)}
          </select>
        </Field>
        <Field label="Year to">
          <select className={inputClass} value={yearMax} onChange={(e) => setYearMax(Number(e.target.value))}>
            {Array.from({ length: 8 }, (_, i) => 2019 + i).map((y) => <option key={y} value={y}>{y}</option>)}
          </select>
        </Field>
      </div>
      <Field label={`Max price — ${formatNairaShort(priceMax)}`}>
        <input type="range" min={PRICE_MIN} max={PRICE_MAX} step={1000000} value={priceMax}
          onChange={(e) => setPriceMax(Number(e.target.value))} className="w-full accent-[oklch(0.62_0.16_255)]" />
      </Field>
      <Field label={`Max mileage — ${mileageMax.toLocaleString("en-NG")} km`}>
        <input type="range" min={0} max={130000} step={1000} value={mileageMax}
          onChange={(e) => setMileageMax(Number(e.target.value))} className="w-full accent-[oklch(0.62_0.16_255)]" />
      </Field>
      <Field label="Transmission">
        <select className={inputClass} value={transmission} onChange={(e) => setTransmission(e.target.value)}>
          <option value="">Any</option>
          {TRANSMISSIONS.map((t) => <option key={t} value={t}>{t}</option>)}
        </select>
      </Field>
      <Field label="Fuel">
        <select className={inputClass} value={fuel} onChange={(e) => setFuel(e.target.value)}>
          <option value="">Any</option>
          {FUELS.map((f) => <option key={f} value={f}>{f}</option>)}
        </select>
      </Field>
      <Field label="Engine">
        <select className={inputClass} value={engine} onChange={(e) => setEngine(e.target.value)}>
          <option value="">Any</option>
          {ENGINE_OPTIONS.map((e2) => <option key={e2} value={e2}>{e2}</option>)}
        </select>
      </Field>
      <Field label="Colour">
        <select className={inputClass} value={colour} onChange={(e) => setColour(e.target.value)}>
          <option value="">Any</option>
          {COLOUR_OPTIONS.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
      </Field>
      <Field label="Location">
        <select className={inputClass} value={location} onChange={(e) => setLocation(e.target.value)}>
          <option value="">Anywhere in Nigeria</option>
          {LOCATION_OPTIONS.map((l) => <option key={l} value={l}>{l}</option>)}
        </select>
      </Field>
      <Field label="Availability">
        <select className={inputClass} value={availability} onChange={(e) => setAvailability(e.target.value)}>
          <option value="">Any status</option>
          {AVAILABILITY_OPTIONS.map((a) => <option key={a} value={a}>{a}</option>)}
        </select>
      </Field>
      <label className="flex items-center gap-3 text-sm text-muted-foreground">
        <input type="checkbox" checked={featuredOnly} onChange={(e) => setFeaturedOnly(e.target.checked)}
          className="h-4 w-4 accent-[oklch(0.62_0.16_255)]" />
        Featured / newly added only
      </label>
      <Button type="button" variant="chrome" size="lg" className="w-full" onClick={reset}>Reset filters</Button>
    </div>
  );

  return (
    <>
      <PageHero
        eyebrow="The Collection"
        title={`${vehicles.length} curated vehicles, priced in Naira.`}
        lead="Filter by brand, model, year, price, body type, mileage, transmission, fuel, engine, colour, location and availability."
      />
      <div className="mx-auto max-w-7xl gap-10 px-5 py-12 sm:px-6 lg:flex">
        <aside className="hidden w-72 shrink-0 lg:block">
          <div className="glass-panel sticky top-24 max-h-[80vh] overflow-y-auto rounded-lg p-5">
            <h2 className="eyebrow mb-4">Refine</h2>
            {filters}
          </div>
        </aside>

        <div className="min-w-0 flex-1">
          <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
            <p className="text-sm text-muted-foreground">
              <span className="text-foreground">{results.length}</span> vehicles match
            </p>
            <div className="flex items-center gap-2">
              <Button variant="chrome" size="lg" className="lg:hidden" onClick={() => setFiltersOpen(true)}>
                <SlidersHorizontal className="h-4 w-4" /> Filters
              </Button>
              <select value={sort} onChange={(e) => setSort(e.target.value)} aria-label="Sort vehicles"
                className="h-11 rounded-md border border-input bg-secondary/50 px-3 text-sm">
                {SORTS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
              </select>
            </div>
          </div>

          {results.length === 0 ? (
            <div className="glass-panel rounded-lg p-12 text-center">
              <h3 className="font-display text-2xl">No vehicles match those filters</h3>
              <p className="mt-3 text-sm text-muted-foreground">Try widening your price or mileage range.</p>
              <Button variant="hero" size="lg" className="mt-6" onClick={reset}>Reset filters</Button>
            </div>
          ) : (
            <>
              <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
                {results.slice(0, visible).map((v, i) =>
                  i === 0 ? (
                    <div key={v.id} className="sm:col-span-2 xl:col-span-3">
                      <VehicleCard vehicle={v} variant="editorial" priority />
                    </div>
                  ) : (
                    <VehicleCard key={v.id} vehicle={v} />
                  ),
                )}
              </div>
              {visible < results.length && (
                <div className="mt-10 text-center">
                  <Button variant="hero" size="xl" onClick={() => setVisible((v) => v + 12)}>
                    Load more vehicles
                  </Button>
                </div>
              )}
            </>
          )}

          <p className="mt-10 text-xs text-muted-foreground">
            Need something not listed? <Link to="/contact" className="text-pearl underline-offset-4 hover:underline">Send a sourcing request</Link>.
          </p>
        </div>
      </div>

      {filtersOpen && (
        <div className="fixed inset-0 z-[70] lg:hidden">
          <button type="button" aria-label="Close filters" className="absolute inset-0 bg-abyss/80" onClick={() => setFiltersOpen(false)} />
          <div className="glass-panel absolute inset-x-0 bottom-0 max-h-[85vh] overflow-y-auto rounded-t-2xl p-5">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="eyebrow">Refine</h2>
              <button type="button" onClick={() => setFiltersOpen(false)} aria-label="Close filters" className="p-2">
                <X className="h-5 w-5" />
              </button>
            </div>
            {filters}
            <Button variant="hero" size="xl" className="mt-4 w-full" onClick={() => setFiltersOpen(false)}>
              Show {results.length} vehicles
            </Button>
          </div>
        </div>
      )}
    </>
  );
}
