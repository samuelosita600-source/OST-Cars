import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { PageHero, Section } from "@/components/site/Section";
import { Button } from "@/components/ui/button";
import { Field, inputClass } from "@/components/site/FormBits";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useQuery } from "@tanstack/react-query";
import { VehicleCard } from "@/components/vehicles/VehicleCard";
import { getVehiclesByIds } from "@/data/vehicles";
import { listVehicles } from "@/libs/vehicles.functions";
import { useCompare, useFavorites } from "@/libs/store";
import { formatNaira } from "@/libs/format";
import { useAuth } from "@/libs/auth";
import { supabase } from "@/integrations/supabase/client";
import type { Vehicle } from "@/data/vehicles";

export const Route = createFileRoute("/account")({
  loader: () => listVehicles(),
  head: () => ({
    meta: [
      { title: "Your Account — Saved Cars & Enquiries | OST Luxury Cars" },
      { name: "description", content: "Manage saved vehicles, your compare list, enquiries, test-drive bookings and profile preferences." },
      { property: "og:title", content: "Your Account — Saved Cars & Enquiries | OST Luxury Cars" },
      { property: "og:description", content: "Manage saved vehicles, your compare list, enquiries and profile preferences." },
    ],
  }),
  component: AccountPage,
});

const TABS = ["Saved vehicles", "Compare list", "Enquiries", "Profile"] as const;

function AccountPage() {
  const all = Route.useLoaderData();
  const [tab, setTab] = useState<(typeof TABS)[number]>("Saved vehicles");
  const { user, profile, loading, isAdmin, refreshProfile, signOut } = useAuth();
  const navigate = useNavigate();
  const { favorites } = useFavorites();
  const { compare } = useCompare();
  const saved = getVehiclesByIds(favorites, all);
  const comparing = getVehiclesByIds(compare, all);

  useEffect(() => {
    if (!loading && !user) void navigate({ to: "/login", replace: true });
  }, [loading, user, navigate]);

  const { data: enquiries } = useQuery({
    queryKey: ["my-enquiries", user?.id],
    enabled: Boolean(user),
    queryFn: async () => {
      const { data, error } = await supabase
        .from("enquiries")
        .select("id, kind, status, message, created_at, vehicle_id")
        .eq("user_id", user?.id ?? "")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  if (!user) {
    return (
      <Section>
        <div className="glass-panel rounded-lg p-12 text-center">
          <p className="text-sm text-muted-foreground">Checking your session…</p>
        </div>
      </Section>
    );
  }

  return (
    <>
      <PageHero
        eyebrow="Your account"
        title="Client dashboard."
        lead={`Signed in as ${profile?.email ?? user.email}. Your saved cars and enquiries are stored securely to your account.`}
      />
      <Section>
        <div className="mb-6 flex flex-wrap items-center gap-3">
          {isAdmin && (
            <Button asChild variant="hero" size="lg"><Link to="/admin">Open admin dashboard</Link></Button>
          )}
          <Button variant="chrome" size="lg" onClick={async () => { await signOut(); void navigate({ to: "/login", replace: true }); }}>
            Sign out
          </Button>
        </div>

        <div className="flex flex-wrap gap-2">
          {TABS.map((t) => (
            <button key={t} type="button" onClick={() => setTab(t)}
              className={`rounded-full px-4 py-2.5 text-[0.66rem] tracking-[0.16em] uppercase transition-colors ${tab === t ? "bg-primary text-primary-foreground" : "border border-border text-muted-foreground hover:text-foreground"}`}>
              {t}
            </button>
          ))}
        </div>

        <div className="mt-8">
          {tab === "Saved vehicles" && (saved.length ? (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{saved.map((v) => <VehicleCard key={v.id} vehicle={v} />)}</div>
          ) : <Empty label="No saved vehicles yet." />)}

          {tab === "Compare list" && (comparing.length ? (
            <ul className="glass-panel divide-y divide-border rounded-lg">
              {comparing.map((v) => (
                <li key={v.id} className="flex items-center justify-between gap-4 p-5">
                  <span className="text-sm">{v.year} {v.brand} {v.model}</span>
                  <span className="text-sm text-pearl">{formatNaira(v.price)}</span>
                </li>
              ))}
            </ul>
          ) : <Empty label="Nothing in your compare list." />)}

          {tab === "Enquiries" && (enquiries && enquiries.length ? (
            <ul className="glass-panel divide-y divide-border rounded-lg">
              {enquiries.map((e) => {
                const v = all.find((x: Vehicle) => x.id === e.vehicle_id);
                return (
                  <li key={e.id} className="p-5">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <span className="text-sm">
                        {e.kind}{v ? ` — ${v.year} ${v.brand} ${v.model}` : ""}
                      </span>
                      <span className="rounded-full border border-border px-3 py-1 text-[0.6rem] tracking-[0.18em] uppercase text-pearl">{e.status}</span>
                    </div>
                    {e.message && <p className="mt-2 text-xs text-muted-foreground">{e.message}</p>}
                    <p className="mt-2 text-[0.6rem] tracking-[0.2em] uppercase text-muted-foreground">
                      {new Date(e.created_at).toLocaleDateString("en-NG")}
                    </p>
                  </li>
                );
              })}
            </ul>
          ) : <Empty label="No enquiries yet." />)}

          {tab === "Profile" && (
            <form className="glass-panel grid max-w-2xl gap-4 rounded-lg p-7 sm:grid-cols-2"
              onSubmit={async (e) => {
                e.preventDefault();
                const form = new FormData(e.currentTarget);
                const { error } = await supabase.from("profiles").update({
                  full_name: String(form.get("name") ?? ""),
                  phone: String(form.get("phone") ?? ""),
                  email: String(form.get("email") ?? ""),
                  preferred_contact: String(form.get("contact") ?? "WhatsApp"),
                }).eq("id", user.id);
                if (error) { toast.error("Could not save", { description: error.message }); return; }
                await refreshProfile();
                toast.success("Profile updated");
              }}>
              <Field label="Full name"><input name="name" defaultValue={profile?.full_name ?? ""} className={inputClass} placeholder="Your name" /></Field>
              <Field label="Phone / WhatsApp"><input name="phone" type="tel" defaultValue={profile?.phone ?? ""} className={inputClass} placeholder="080 0000 0000" /></Field>
              <Field label="Email"><input name="email" type="email" defaultValue={profile?.email ?? user.email ?? ""} className={inputClass} placeholder="you@example.com" /></Field>
              <Field label="Preferred contact">
                <select name="contact" defaultValue={profile?.preferred_contact ?? "WhatsApp"} className={inputClass}>
                  <option>WhatsApp</option><option>Phone</option><option>Email</option>
                </select>
              </Field>
              <div className="sm:col-span-2"><Button type="submit" variant="hero" size="lg">Save preferences</Button></div>
            </form>
          )}
        </div>
      </Section>
    </>
  );
}

function Empty({ label }: { label: string }) {
  return (
    <div className="glass-panel rounded-lg p-12 text-center">
      <p className="text-sm text-muted-foreground">{label}</p>
      <Button asChild variant="chrome" size="lg" className="mt-6"><Link to="/inventory">Browse the collection</Link></Button>
    </div>
  );
}
