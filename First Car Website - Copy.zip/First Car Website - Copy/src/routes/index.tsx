import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ShieldCheck,
  BadgeCheck,
  Wallet,
  Headphones,
  Truck,
  FileCheck2,
  ArrowRight,
  MessageCircle,
  Quote,
} from "lucide-react";
import { CinematicIntro } from "@/components/cinematic/CinematicIntro";
import { ScrollVideoHero } from "@/components/cinematic/ScrollVideoHero";
import { SpecOrbit } from "@/components/cinematic/SpecOrbit";
import { BeneathSurface } from "@/components/cinematic/BeneathSurface";
import { QuickSearch } from "@/components/site/QuickSearch";
import { Section } from "@/components/site/Section";
import { VehicleCard } from "@/components/vehicles/VehicleCard";
import { Button } from "@/components/ui/button";
import { CATEGORIES, type Vehicle } from "@/data/vehicles";
import { listVehicles } from "@/libs/vehicles.functions";
import { POSTS } from "@/data/content";
import { formatNaira, whatsappLink } from "@/libs/format";

export const Route = createFileRoute("/")({
  loader: () => listVehicles(),
  head: () => ({
    meta: [
      { title: "OST Luxury Cars — Luxury Cars in Nigeria | Choose Ur Car Wisely" },
      {
        name: "description",
        content:
          "Discover curated luxury cars in Nigeria. Inspected SUVs, executive sedans, performance and electric vehicles priced in Naira, with financing support and concierge delivery.",
      },
      { property: "og:title", content: "OST Luxury Cars — Choose Ur Car Wisely" },
      {
        property: "og:description",
        content: "A cinematic luxury automotive house in Nigeria. Discover, compare, finance and reserve.",
      },
    ],
  }),
  component: Home,
});

const WHY = [
  { Icon: BadgeCheck, title: "Verified sourcing", copy: "Vehicles sourced through trusted channels with documented history." },
  { Icon: ShieldCheck, title: "Multi-point inspection", copy: "Mechanical, electrical and cosmetic checks before listing." },
  { Icon: Wallet, title: "Transparent pricing", copy: "Naira pricing with no hidden add-ons — what you see is what we discuss." },
  { Icon: Headphones, title: "Concierge service", copy: "One dedicated contact from enquiry to handover." },
  { Icon: Truck, title: "Nationwide support", copy: "Delivery and after-sales coordination across Nigeria." },
  { Icon: FileCheck2, title: "Documentation guidance", copy: "Support with paperwork, customs and registration processes." },
];

const TESTIMONIALS = [
  {
    quote: "The inspection report was thorough and the handover felt like a private showing. Very few dealers in Lagos operate at this level.",
    name: "Chidi O.",
    role: "Bought a Range Rover Sport, Lekki",
  },
  {
    quote: "They sourced the exact spec I wanted and kept me updated weekly until it landed. Straightforward pricing throughout.",
    name: "Aisha B.",
    role: "Import sourcing, Abuja",
  },
  {
    quote: "Traded in my old SUV and drove out the same week. Professional from the first WhatsApp message.",
    name: "Emeka N.",
    role: "Trade-in client, Port Harcourt",
  },
];

function Home() {
  const vehicles = Route.useLoaderData();
  const featuredArrivals = (vehicles.filter((v: Vehicle) => v.featured).length ? vehicles.filter((v: Vehicle) => v.featured) : vehicles).slice(0, 5);
  const compareTeaser = vehicles.slice(0, 3);
  const featuredVehicle = featuredArrivals[0] ?? vehicles[0];

  return (
    <>
      <CinematicIntro />
      <ScrollVideoHero />
      <QuickSearch />
      {featuredVehicle && <SpecOrbit vehicle={featuredVehicle} />}

      {/* Categories */}
      <Section
        eyebrow="Curated collections"
        title="Find your category, not just a car."
        lead="Eight curated collections covering the vehicles Nigerian buyers actually ask us for."
      >
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {CATEGORIES.map((c, i) => (
            <Link
              key={c.label}
              to="/inventory"
              search={{ body: c.label }}
              className="reveal group glass-panel sheen-hover relative block overflow-hidden rounded-lg"
              style={{ transitionDelay: `${i * 60}ms` }}
            >
              <img
                src={c.image}
                alt={`${c.label} collection`}
                loading="lazy"
                width={1400}
                height={900}
                className="h-40 w-full object-cover opacity-70 transition-all duration-700 group-hover:scale-105 group-hover:opacity-100"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-abyss via-abyss/40 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-4">
                <h3 className="font-display text-lg">{c.label}</h3>
                <p className="mt-1 text-xs text-muted-foreground">{c.blurb}</p>
                <span className="mt-3 flex items-center gap-1.5 text-[0.6rem] tracking-[0.22em] uppercase text-pearl">
                  Explore <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-1" />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </Section>

      <BeneathSurface />

      {/* Featured arrivals */}
      <Section
        eyebrow="Featured arrivals"
        title="Newly curated, ready for viewing."
        lead="A rotating selection from our current inventory. Every unit inspected and priced in Naira."
      >
        <div className="space-y-4">
          {featuredArrivals[0] && (
            <div className="reveal">
              <VehicleCard vehicle={featuredArrivals[0]} variant="editorial" priority />
            </div>
          )}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {featuredArrivals.slice(1).map((v: Vehicle, i: number) => (
              <div key={v.id} className="reveal" style={{ transitionDelay: `${i * 70}ms` }}>
                <VehicleCard vehicle={v} />
              </div>
            ))}
          </div>
        </div>
        <div className="mt-10 flex flex-wrap gap-3">
          <Button asChild variant="hero" size="lg">
            <Link to="/inventory">View all {vehicles.length} vehicles</Link>
          </Button>
          <Button asChild variant="chrome" size="lg">
            <Link to="/favorites">Saved cars</Link>
          </Button>
        </div>
      </Section>

      {/* Why OST */}
      <Section
        eyebrow="Why OST Luxury Cars"
        title="Confidence is part of the specification."
        lead="We built the process we wished existed when buying luxury vehicles in Nigeria."
        className="border-y border-border bg-abyss-gradient"
      >
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {WHY.map((w, i) => (
            <div
              key={w.title}
              className="reveal glass-panel rounded-lg p-6"
              style={{ transitionDelay: `${i * 60}ms` }}
            >
              <w.Icon className="h-6 w-6 text-pearl" />
              <h3 className="font-display mt-4 text-xl">{w.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{w.copy}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* Compare teaser */}
      <Section eyebrow="Compare" title="Two to four cars, side by side." lead="Add vehicles as you browse and see exactly where they differ — price, year, mileage, engine and features.">
        <div className="grid gap-4 sm:grid-cols-3">
          {compareTeaser.map((v: Vehicle) => (
            <div key={v.id} className="reveal glass-panel rounded-lg p-5">
              <p className="eyebrow">{v.brand}</p>
              <h3 className="font-display mt-1.5 text-lg">{v.model}</h3>
              <dl className="mt-4 space-y-2 text-xs text-muted-foreground">
                <div className="flex justify-between">
                  <dt>Price</dt>
                  <dd className="text-foreground">{formatNaira(v.price)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt>Engine</dt>
                  <dd className="text-foreground">{v.engine}</dd>
                </div>
                <div className="flex justify-between">
                  <dt>Power</dt>
                  <dd className="text-foreground">{v.power}</dd>
                </div>
              </dl>
            </div>
          ))}
        </div>
        <Button asChild variant="chrome" size="lg" className="mt-8">
          <Link to="/compare">Open compare</Link>
        </Button>
      </Section>

      {/* Finance + trade-in */}
      <Section className="border-y border-border bg-abyss-gradient">
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="reveal glass-panel rounded-lg p-8 sm:p-10">
            <p className="eyebrow">Financing</p>
            <h2 className="font-display mt-4 text-3xl">Estimate your monthly outlay.</h2>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              Adjust deposit, duration and an indicative rate to see an estimated monthly figure in Naira. Estimates
              only — subject to lender assessment and approval.
            </p>
            <Button asChild variant="hero" size="lg" className="mt-7">
              <Link to="/financing">Open finance estimator</Link>
            </Button>
          </div>
          <div className="reveal glass-panel rounded-lg p-8 sm:p-10">
            <p className="eyebrow">Sell or trade-in</p>
            <h2 className="font-display mt-4 text-3xl">Your current car is part of the deal.</h2>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              Share your vehicle details and we will revert with an indicative valuation range and next steps for
              inspection.
            </p>
            <Button asChild variant="chrome" size="lg" className="mt-7">
              <Link to="/sell">Request a valuation</Link>
            </Button>
          </div>
        </div>
      </Section>

      {/* Testimonials */}
      <Section eyebrow="Client confidence" title="Quietly recommended." align="center">
        <div className="grid gap-6 lg:grid-cols-3">
          {TESTIMONIALS.map((t, i) => (
            <blockquote
              key={t.name}
              className="reveal glass-panel rounded-lg p-7"
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <Quote className="h-5 w-5 text-pearl" />
              <p className="mt-4 text-sm leading-relaxed text-foreground/90">{t.quote}</p>
              <footer className="mt-5 text-xs text-muted-foreground">
                <span className="text-foreground">{t.name}</span> · {t.role}
              </footer>
            </blockquote>
          ))}
        </div>
      </Section>

      {/* Journal */}
      <Section
        eyebrow="Journal"
        title="Ownership guides & market notes."
        lead="Practical reading for luxury vehicle owners in Nigeria."
        className="border-t border-border"
      >
        <div className="grid gap-4 sm:grid-cols-3">
          {POSTS.slice(0, 3).map((p, i) => (
            <Link
              key={p.slug}
              to="/blog"
              className="reveal glass-panel sheen-hover group relative overflow-hidden rounded-lg p-6"
              style={{ transitionDelay: `${i * 70}ms` }}
            >
              <p className="eyebrow">{p.category}</p>
              <h3 className="font-display mt-3 text-xl leading-snug transition-colors group-hover:text-pearl">
                {p.title}
              </h3>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{p.excerpt}</p>
              <p className="mt-5 text-[0.6rem] tracking-[0.22em] uppercase text-muted-foreground">
                {p.date} · {p.readTime}
              </p>
            </Link>
          ))}
        </div>
      </Section>

      {/* WhatsApp concierge */}
      <section className="relative overflow-hidden border-t border-border py-24">
        <div
          className="pointer-events-none absolute inset-x-0 -bottom-40 h-80 opacity-25 blur-[120px]"
          style={{ backgroundImage: "var(--gradient-pearl)" }}
        />
        <div className="relative mx-auto max-w-3xl px-5 text-center sm:px-6">
          <p className="eyebrow">Concierge</p>
          <h2 className="font-display mt-4 text-3xl sm:text-5xl">
            <span className="text-pearl-gradient">Choose Ur Car Wisely.</span>
          </h2>
          <p className="mx-auto mt-5 max-w-xl text-sm leading-relaxed text-muted-foreground sm:text-base">
            Tell us what you are looking for and your budget in Naira. A concierge will respond on WhatsApp with matched
            options from our inventory or sourcing network.
          </p>
          <div className="mt-9 flex flex-wrap justify-center gap-3">
            <Button asChild variant="whatsapp" size="xl">
              <a
                href={whatsappLink("Hello OST Luxury Cars, I would like help choosing a vehicle.")}
                target="_blank"
                rel="noopener noreferrer"
              >
                <MessageCircle className="h-4 w-4" />
                Chat on WhatsApp
              </a>
            </Button>
            <Button asChild variant="chrome" size="xl">
              <Link to="/contact">Contact the showroom</Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}
