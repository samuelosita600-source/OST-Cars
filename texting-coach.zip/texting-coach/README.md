# Texting & Dating Coach

A personal chat app with a built-in texting/dating coach persona that **remembers things about you and gets more personalized over time** — it can't retrain itself, but it accumulates facts about your patterns and the people you're talking to, and folds them into every future conversation.

## Setup in GitHub Codespaces

1. Push this repo to GitHub (or upload it, then create a Codespace on it).
2. Open in Codespaces.
3. In the terminal:
   ```bash
   npm install
   cp .env.example .env
   ```
4. Open `.env` and paste in your own Anthropic API key (get one at https://console.anthropic.com/):
   ```
   ANTHROPIC_API_KEY=sk-ant-...
   ```
5. Start it:
   ```bash
   npm start
   ```
6. Codespaces will prompt you to open the forwarded port in browser — click it.

## How the "self-improving" part works

- `persona.js` holds the core coaching identity (feel free to edit it).
- `memory.json` holds facts learned about you and people you're texting.
- Every chat call rebuilds the system prompt using current `memory.json`.
- Hit the **Learn** button after a session — it reads the conversation, extracts anything new and durable (patterns, growth areas, notes on specific people), and merges it into `memory.json`.
- Next session, the coach already knows it — no re-explaining yourself.

## Files

- `server.js` — Express backend, `/api/chat` and `/api/learn` endpoints
- `persona.js` — the coach's system prompt + how memory gets woven in
- `memory.json` — persistent memory (safe to hand-edit or wipe)
- `public/index.html` — the chat UI

## Notes

- This uses the `claude-sonnet-4-6` model via the Anthropic API. Each message costs a small amount against your API key's usage.
- `memory.json` is local to your repo — don't commit real names/details of people you're texting if you plan to make the repo public. Consider adding it to `.gitignore` if so.
