require("dotenv").config();
const express = require("express");
const fs = require("fs");
const path = require("path");
const Anthropic = require("@anthropic-ai/sdk");
const { buildSystemPrompt } = require("./persona");

const app = express();
app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));

const MEMORY_PATH = path.join(__dirname, "memory.json");
const MODEL = "claude-sonnet-4-6";

if (!process.env.ANTHROPIC_API_KEY) {
  console.warn("\n⚠️  No ANTHROPIC_API_KEY found. Copy .env.example to .env and add your key.\n");
}

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

function loadMemory() {
  return JSON.parse(fs.readFileSync(MEMORY_PATH, "utf-8"));
}

function saveMemory(memory) {
  fs.writeFileSync(MEMORY_PATH, JSON.stringify(memory, null, 2));
}

// Main chat endpoint
app.post("/api/chat", async (req, res) => {
  try {
    const { messages } = req.body; // [{role: "user"|"assistant", content: "..."}]
    const memory = loadMemory();
    const system = buildSystemPrompt(memory);

    const response = await client.messages.create({
      model: MODEL,
      max_tokens: 1000,
      system,
      messages,
    });

    const text = response.content
      .filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("\n");

    res.json({ reply: text });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// Self-improvement endpoint: reads the conversation and folds new facts into memory.json
app.post("/api/learn", async (req, res) => {
  try {
    const { messages } = req.body;
    const memory = loadMemory();

    const extractionPrompt = `Here is a coaching conversation between Samuel (19) and his AI texting/dating coach.

Existing known facts about Samuel:
${JSON.stringify(memory.learned_facts || [])}

Existing tracked people:
${JSON.stringify(memory.recurring_people || [])}

Conversation:
${messages.map((m) => `${m.role.toUpperCase()}: ${m.content}`).join("\n\n")}

Extract anything NEW and durably useful for future coaching sessions:
- New facts about Samuel's texting patterns, tendencies, strengths, or growth areas
- New or updated info about a specific girl/person he's talking to (name + short notes)
- Skip anything trivial, one-off, or already known

Respond ONLY with JSON, no markdown, no preamble, in this exact shape:
{"new_facts": ["..."], "people_updates": [{"name": "...", "notes": "..."}]}
If there's nothing new, return {"new_facts": [], "people_updates": []}.`;

    const response = await client.messages.create({
      model: MODEL,
      max_tokens: 600,
      messages: [{ role: "user", content: extractionPrompt }],
    });

    const raw = response.content
      .filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("\n")
      .replace(/```json|```/g, "")
      .trim();

    const parsed = JSON.parse(raw);

    memory.learned_facts = memory.learned_facts || [];
    memory.recurring_people = memory.recurring_people || [];
    memory.session_log = memory.session_log || [];

    for (const fact of parsed.new_facts || []) {
      if (!memory.learned_facts.includes(fact)) memory.learned_facts.push(fact);
    }

    for (const update of parsed.people_updates || []) {
      const existing = memory.recurring_people.find(
        (p) => p.name.toLowerCase() === update.name.toLowerCase()
      );
      if (existing) {
        existing.notes = update.notes;
      } else {
        memory.recurring_people.push(update);
      }
    }

    memory.session_log.push({
      timestamp: new Date().toISOString(),
      facts_added: (parsed.new_facts || []).length,
      people_updated: (parsed.people_updates || []).length,
    });

    saveMemory(memory);
    res.json({ ok: true, memory });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/memory", (req, res) => {
  res.json(loadMemory());
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Texting coach running at http://localhost:${PORT}`));
